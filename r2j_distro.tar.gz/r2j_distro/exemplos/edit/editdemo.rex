/* REXX - editdemo: ISPEXEC EDIT/VIEW com STEM e com arquivo                 */
/* EDIT STEM: PF3 atualiza o stem, PF12 descarta as alteracoes               */
do i = 1 to 8; linha.i = 'Registro' right(i, 3, '0') 'conteudo de exemplo'; end
linha.0 = 8
address ispexec
"EDIT STEM(LINHA)"
if rc = 0 then say 'stem atualizado:' linha.0 'linhas'
else say 'edicao cancelada / sem alteracoes (rc='rc')'
do i = 1 to linha.0; say right(i,3) linha.i; end
/* arquivo: grava o stem e abre em EDIT (SAVE grava) e depois em VIEW */
arq = 'editdemo.txt'
call stream arq, 'C', 'OPEN WRITE REPLACE'
do i = 1 to linha.0; call lineout arq, linha.i; end
call lineout arq
"EDIT DATASET('"arq"')"
say 'EDIT arquivo rc='rc
"VIEW DATASET('"arq"')"
say 'VIEW rc='rc
exit 0
