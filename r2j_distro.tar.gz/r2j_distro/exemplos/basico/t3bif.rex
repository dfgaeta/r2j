/* REXX - t3bif: builtin functions */
say abbrev('PRINT','PRI') abbrev('PRINT','PRY') abbrev('PRINT','',0) abs(-12.50) center('abc',7,'*') center('abcdefg',3)
say changestr('a','banana','o') countstr('an','banana') compare('abc','abd') compare('ab ','ab') copies('ab',3)
say datatype(' 12 ') datatype('x1') datatype('12','W') datatype('1.5','W') datatype('aBc','M') datatype('FF','X') datatype('0101','B')
say delstr('abcdef',3,2) delword('now is the time',2,2) insert('123','abc',5,6,'+') lastpos(' ','a b c') left('abc',5,'.') right('abc',5,'0')
say length('hello') max(1,7.5,-3) min(4,2,9) overlay('XY','abcdef',3) pos('de','abcdef') reverse('abc') sign(-3) sign(0)
say space('  a  b   c ') space('a b c',2,'-') strip('  xx  ')'|' strip('00120','L','0') strip('xxaxx','B','x')
say substr('abcdef',2,3) substr('abc',2,5,'.') subword('the quick brown fox',2,2) translate('abc') translate('abc','xy','ab')
say trunc(12.789,2) trunc(-3.9) verify('123a5','0123456789') verify('abc','b','M') word('a bb ccc',2) wordindex('a bb ccc',3) wordlength('a bb ccc',3)
say wordpos('brown fox','the quick brown fox') words('  one two  three ') xrange('a','e') c2x(xrange('00'x,'03'x))
say format(3.14159,4,2)'|' format(-1.5,3,0)'|' format(1234.5,,1) format(0.000123,,,0) format(12345.678,,2,2)
say format(1.5e10) format(123,,,3) d2x(4095) d2x(255,4) d2c(97,2)=='00'x'a' x2d('0FFF') x2d('8000',4) c2d('0102'x)
say date('S') = date('S',date('B'),'B') date('W','20261124','S') date('N','20260101','S') date('B','01/01/01','U') date('E','2026-11-24','I')
say length(time()) length(time('L')) time('C','14:05:00') time('M','01:30:00') time('H','23:59:59')
say queued() digits() fuzz() form() address() arg(1,'E') arg(1,'O')
say errortext(16) '|' sourceline(1)
say bitand('73'x,'27'x)=='23'x bitor('15'x,'24'x)=='35'x bitxor('12'x,'22'x)=='30'x
numeric digits 5
say 123456 * 2 1/3 trunc(1.23456789,8)
numeric form engineering
say 123456 * 100
numeric form scientific
numeric digits 9
say random(5,5) (random(1,6) >= 1) userid() <> ''
x.1 = 'a'; x.2 = 'b'; x.0 = 2
say value('x.' || 2) symbol('x.1') symbol('x.9')
say justify('a b c',9) '|'justify('the quick fox', 17, '_')
say 'upper/lower:' upper('abc') lower('ABC')
say 'x2b' x2b('A1') 'b2x' b2x('1010 0001') 'c2d' c2d('81'x, 1)
