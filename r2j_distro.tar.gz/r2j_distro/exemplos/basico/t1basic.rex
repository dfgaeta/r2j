/* REXX - t1basic: expressions, strings, numbers, flows */
parse arg p1 p2 .
say 'args:' p1 p2 'arg()='arg()
a = 10; b = 3
say a+b a-b a*b a/b a%b a//b a**b -a**2
say 1/3 2/3 10/4 6/2 1.50+1.50 1.5*2 0.1+0.2
say 12345678 * 1000  1e3 + 1 '007'+0 '  12 '+1
numeric digits 20
say 2**64 1/7
numeric digits
say 1/7 2**40
x = 'abc'
say x||'def' x 'def' x"def" (x)(x)
say 'abc' = '  abc  ' 'abc' == '  abc' 5 = 5.0 '5' == '5.0'
say (1 < 2) (2 > 1) \(1=1) (1=1 & 0=1) (1=1 | 0=1) (1 && 1)
/* compound and stems */
s. = 'none'
s.1 = 'one'; i = 2; s.i = 'two'
j = 1
say s.1 s.2 s.3 s.j s.i.j
drop s.1
say s.1
t.a.b = 'ab'; a1 = 'A'; b1 = 'B'
say t.a1.b1 symbol('t.a.b') symbol('zz') symbol('1x') symbol('?')
/* loops */
tot = 0
do i = 1 to 10 by 2
  tot = tot + i
end
say 'sum odd' tot i
do i = 10 to 1 by -3; call charout , i' '; end; say
do 3; call charout , '*'; end; say
n = 0
do forever
  n = n + 1
  if n // 2 = 0 then iterate
  if n > 7 then leave
  call charout , n
end
say ' n='n
do i = 1 to 3
  do j = 1 to 3
    if j = 2 then iterate i
    if i = 3 then leave i
    call charout , i'.'j' '
  end j
end i
say
k = 0; do while k < 3; k = k + 1; end; say 'while' k
k = 0; do until k >= 5; k = k + 1; end; say 'until' k
do i = 1 for 4 while i < 3; say 'for/while' i; end
/* select */
do v = 1 to 4
  select
    when v = 1 then say 'one'
    when v = 2 then do
        say 'two'
      end
    otherwise say 'other' v
  end
end
/* if else chains */
z = 5
if z > 3 then if z > 4 then say 'z>4'; else say 'z<=4'
else say 'z<=3'
/* hex / bin */
say '414243'x 'C1'x == 'c1'x '0100 0001'b c2x('AB') x2c('3132') x2d('FF') x2d('FF',2) d2x(255) d2c(65)
say b2x('11110000') x2b('F0') c2d('A') c2d('FF'x,1) d2x(-1,4)
exit 0
