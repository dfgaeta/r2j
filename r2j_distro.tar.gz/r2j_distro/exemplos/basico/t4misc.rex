/* REXX - t4misc: trace, signal out of loops, drop, upper, numeric, errors */
trace r
a = 1 + 2
trace off
do i = 1 to 100
  do j = 1 to 100
    if i * j = 12 & j = 4 then signal found
  end
end
found:
say 'found i='i 'j='j
v = 'abc'; upper v; say v
drop v; say v symbol('v')
call sub1
say 'back' result
s.x = 1; s.y = 2
drop s.
say s.x s.y
n = 0
do i = 1 to 5
   call on error name e1
   'exit' i // 2
end
say 'errors' n
numeric fuzz 2
say (1.23456789 = 1.23456700)
numeric fuzz 0
say (1.23456789 = 1.23456700)
interpret 'do k = 1 to 3; if k = 2 then leave; say "loop" k; end'
say 'rc:' rc 'sigl' sigl
say 'divide' 10 / 0
exit
sub1:
  return 'from sub1'
e1:
  n = n + 1
  return
