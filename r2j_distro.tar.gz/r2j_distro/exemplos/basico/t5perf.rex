/* REXX perf */
t = 0
do i = 1 to 1000000
  t = t + i // 7
  s.i = i
end
say t s.500000 words(copies('a ', 1000))
say fib(22)
exit
fib: procedure
  arg n
  if n < 2 then return n
  return fib(n-1) + fib(n-2)
