/* REXX - t2proc: routines, procedure expose, signal, conditions, interpret, parse */
signal on syntax name trapsyn
signal on novalue
counter = 0
list. = 0
say 'fact(10) =' fact(10)
say 'fib(15)  =' fib(15)
call incr 5
call incr 7
say 'counter' counter 'result' result
call fill 3
say 'list.0' list.0 list.1 list.2 list.3
say 'noproc:' noproc('x')  'g='g
names = 'counter list.'
call viaList
say 'after viaList counter=' counter
/* parse */
parse value 'John Smith 42 Rua A, 100' with first last age street ',' number
say first'|'last'|'age'|'street'|'number
parse value 'abcdefghij' with 3 x 6 y +2 z
say x y z
data = 'k1=v1;k2=v2;k3=v3'
do while data <> ''
  parse var data key '=' val ';' data
  say '  key' key 'val' val
end
pat = '-'
parse value '2026-11-24' with yy (pat) mm (pat) dd
say dd'/'mm'/'yy
parse upper value 'mixed Case' with u1 u2
say u1 u2
parse value '  lead   words  here ' with w1 rest
say '['w1']['rest']'
parse source s1 s2 s3
say 'source' s1 s2 s3
parse version v1 .
say 'version' v1
/* interpret */
interpret 'iv = 6 * 7'
say 'interpret' iv
do i = 1 to 3
  interpret 'dyn.'i '= i * 100'
end
say dyn.1 dyn.2 dyn.3
cmdx = 'say "from interpret:" fact(5)'
interpret cmdx
/* value() */
call value 'vv', 'set by value'
say vv value('vv') value('dyn.2')
/* signal value + call on error */
call on error name errhand
address system 'exit 3'
say 'rc after error' rc
lbl = 'JUMP'
signal value lbl
say 'not shown'
jump:
say 'jumped, sigl=' sigl
x = undefinedvar
say 'not reached'
exit 0

fact: procedure
  arg n
  if n <= 1 then return 1
  return n * fact(n - 1)

fib: procedure
  parse arg n
  if n < 2 then return n
  return fib(n-1) + fib(n-2)

incr: procedure expose counter
  counter = counter + arg(1)
  return counter

fill: procedure expose list.
  do i = 1 to arg(1); list.i = i*i; end
  list.0 = arg(1)
  return

noproc:
  g = 'global'
  return arg(1)'!'

viaList: procedure expose (names)
  counter = counter + 1000
  return

errhand:
  say '  ERROR trapped: rc='rc 'cond='condition('C') 'desc='condition('D') 'sigl='sigl
  return

novalue:
  say 'NOVALUE trapped:' condition('D') 'line' sigl
  signal on syntax name trapsyn
  y = 1 / 0
  exit 1

trapsyn:
  say 'SYNTAX trapped rc='rc errortext(rc) 'line' sigl
  exit 8
