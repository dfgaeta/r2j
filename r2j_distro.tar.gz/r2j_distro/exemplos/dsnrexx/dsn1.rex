/* REXX - dsn1: DSNREXX basics - connect, DDL, PREPARE/EXECUTE, cursor */
'SUBCOM DSNREXX'
if rc then s_rc = rxsubcom('ADD','DSNREXX','DSNREXX')

address dsnrexx 'CONNECT' ssid                  /* SSID from [vars] of rexx.cfg */
call chk 'CONNECT'

address dsnrexx
"EXECSQL EXECUTE IMMEDIATE DROP TABLE EMP IF EXISTS"
stmt = 'CREATE TABLE EMP (EMPNO CHAR(6) NOT NULL PRIMARY KEY,',
       ' NAME VARCHAR(30) NOT NULL, DEPT CHAR(3), SALARY DECIMAL(9,2),',
       ' HIRED DATE)'
"EXECSQL EXECUTE IMMEDIATE :stmt"
call chk 'CREATE'

/* insert with parameter markers */
ins = 'INSERT INTO EMP (EMPNO, NAME, DEPT, SALARY, HIRED) VALUES (?, ?, ?, ?, ?)'
"EXECSQL PREPARE S1 FROM :ins"
call chk 'PREPARE S1'
data.1 = '000010 HAAS       A00 52750.00 1995-01-01'
data.2 = '000020 THOMPSON   B01 41250.00 2003-10-10'
data.3 = '000030 KWAN       C01 38250.00 2005-04-05'
data.4 = '000050 GEYER      E01 40175.00 1999-08-17'
data.5 = '000060 STERN      D11 32250.00 2006-09-14'
data.0 = 5
do i = 1 to data.0
  parse var data.i empno name dept salary hired
  "EXECSQL EXECUTE S1 USING :empno, :name, :dept, :salary, :hired"
  call chk 'INSERT' empno
end
"EXECSQL COMMIT"
say 'rows inserted:' data.0

/* cursor with host variables in OPEN USING */
sel = 'SELECT EMPNO, NAME, SALARY, HIRED FROM EMP WHERE SALARY > ? ORDER BY SALARY DESC'
"EXECSQL DECLARE C1 CURSOR FOR S2"
"EXECSQL PREPARE S2 FROM :sel"
minsal = 35000
"EXECSQL OPEN C1 USING :minsal"
call chk 'OPEN C1'
say left('EMPNO',7) left('NAME',12) right('SALARY',10) ' HIRED'
do n = 1 by 1
  "EXECSQL FETCH C1 INTO :e, :nm, :sal, :hd"
  if sqlcode = 100 then leave
  call chk 'FETCH'
  say left(e,7) left(nm,12) right(sal,10) ' 'hd
end
"EXECSQL CLOSE C1"
say n-1 'rows fetched, last SQLCODE' sqlcode

/* update + SQLERRD.3 */
upd = "UPDATE EMP SET SALARY = SALARY * 1.10 WHERE DEPT LIKE ?"
"EXECSQL PREPARE S3 FROM :upd"
pat = 'C%'
"EXECSQL EXECUTE S3 USING :pat"
say 'updated rows (SQLERRD.3):' sqlerrd.3
"EXECSQL COMMIT"

/* extension: direct SQL with INTO */
"EXECSQL SELECT COUNT(*), SUM(SALARY) INTO :cnt, :tot FROM EMP"
say 'count' cnt 'total' tot
address dsnrexx 'DISCONNECT'
exit 0

chk:
  if sqlcode < 0 then do
    say 'SQL ERROR in' arg(1) 'SQLCODE='sqlcode 'SQLSTATE='sqlstate
    say '  ' sqlerrmc
    exit 8
  end
  return
