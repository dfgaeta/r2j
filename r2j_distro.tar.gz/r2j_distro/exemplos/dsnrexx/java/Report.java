/** ADDRESS JCALL 'Report width' - prints the REXX variables of the caller */
public class Report extends r2j {
    @Override
    public int jcall(String[] parms) {
        int w = parms.length > 0 ? Integer.parseInt(parms[0]) : 60;
        say("=".repeat(w));
        for (String n : pool.names()) if (!n.endsWith(".")) say(String.format("  %-10s = %s", n, pool.get(n)));
        say("=".repeat(w));
        return 0;
    }
}
