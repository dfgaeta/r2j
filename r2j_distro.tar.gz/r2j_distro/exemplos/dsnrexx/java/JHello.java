/** ADDRESS JCALL 'hello ...' (alias in rexx.cfg) - a Java class extending r2j */
public class JHello extends r2j {
    @Override
    public int jcall(String[] parms) {
        say("JHello called from " + prog.name + " line " + prog.line + " with " + parms.length + " parameters");
        for (int i = 0; i < parms.length; i++) say("  parm " + (i + 1) + " = [" + parms[i] + "]");
        say("  REXX variable APPL = " + pool.value("APPL") + ", cfg [report] title = " + cfg("report", "title", "?"));
        pool.set("JVAR", "hello from Java");
        result = "OK " + parms.length;
        return parms.length;
    }
}
