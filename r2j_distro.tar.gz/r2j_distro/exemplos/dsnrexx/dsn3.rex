/* REXX - dsn3: SQL error handling - SQLCA, DSNTIAR (LINKPGM and function), SIGNAL ON FAILURE */
address dsnrexx 'CONNECT DB2A'
address dsnrexx

say '--- 1) SQLCA after a failing statement'
"EXECSQL SELECT X INTO :x FROM NO_SUCH_TABLE"
say 'RC='rc 'SQLCODE='sqlcode 'SQLSTATE='sqlstate
say 'SQLERRMC='sqlerrmc
say 'SQLERRD.1-6:' sqlerrd.1 sqlerrd.2 sqlerrd.3 sqlerrd.4 sqlerrd.5 sqlerrd.6

say '--- 2) classic DSNTIAR call through ADDRESS LINKPGM (binary SQLCA built by hand)'
"EXECSQL INSERT INTO EMP (EMPNO, NAME) VALUES ('000010', 'DUPLICATE')"
call build_sqlca
msg   = d2c(10 * 79, 2) || copies(' ', 10 * 79)       /* 2 byte length + area */
lrecl = d2c(79, 4)
address linkpgm 'DSNTIAR SQLCA MSG LRECL'
say 'DSNTIAR RC='rc
area = substr(msg, 3)
do i = 1 to 10
  l = strip(substr(area, (i-1)*79+1, 79), 'T')
  if l <> '' then say l
end

say '--- 3) DSNTIAR() function (uses the REXX SQLCA variables)'
"EXECSQL SELEKT * FROM EMP"
call dsntiar 'TXT.', 72
do i = 1 to txt.0; say txt.i; end

say '--- 4) SQLCODE +100 and -305 (null without indicator)'
"EXECSQL SELECT NAME INTO :nm FROM EMP WHERE EMPNO = '999999'"
say 'not found: RC='rc 'SQLCODE='sqlcode
"EXECSQL SELECT CAST(NULL AS DATE) INTO :hd FROM SYSIBM.SYSDUMMY1"
say 'null: SQLCODE='sqlcode

say '--- 5) SIGNAL ON FAILURE: any negative SQLCODE (RC=-1) jumps to the handler'
signal on failure name sqlfail
"EXECSQL UPDATE EMP SET NAME = NULL WHERE EMPNO = '000010'"
say 'not reached'
exit 0

sqlfail:
  say 'FAILURE trapped at line' sigl 'RC='rc 'command:' condition('D')
  say dsntiar()
  "EXECSQL ROLLBACK"
  address dsnrexx 'DISCONNECT'
  exit 8

/* builds the 136 byte binary SQLCA used by DSNTIAR on z/OS */
build_sqlca:
  sqlca = 'SQLCA   ' || d2c(136, 4) || d2c(sqlcode, 4) ||,
          d2c(length(left(sqlerrmc,70)), 2) || left(sqlerrmc, 70) || left(sqlerrp, 8)
  do k = 1 to 6; sqlca = sqlca || d2c(sqlerrd.k, 4); end
  do k = 0 to 10; sqlca = sqlca || left(sqlwarn.k, 1); end
  sqlca = sqlca || left(sqlstate, 5)
  return
