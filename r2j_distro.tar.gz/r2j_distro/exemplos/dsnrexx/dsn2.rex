/* REXX - dsn2: dynamic SQL with SQLDA (DESCRIBE, FETCH USING DESCRIPTOR, EXECUTE USING DESCRIPTOR) */
parse arg query
if query = '' | query = 'ALL' then query = 'SELECT * FROM EMP ORDER BY EMPNO'
address dsnrexx 'CONNECT DB2A'
address dsnrexx

/* --- output SQLDA --------------------------------------------------------- */
"EXECSQL DECLARE C2 CURSOR FOR S1"
"EXECSQL PREPARE S1 INTO :OUTDA FROM :query"
if sqlcode < 0 then signal sqlerr
say 'query  :' query
say 'columns:' outda.sqld
do i = 1 to outda.sqld
  say '  'right(i,2) left(outda.i.sqlname,10) 'type' outda.i.sqltype typename(outda.i.sqltype),
      'len' outda.i.sqllen 'prec' outda.i.sqllen.sqlprecision 'scale' outda.i.sqllen.sqlscale
end
"EXECSQL OPEN C2"
hdr = ''
do i = 1 to outda.sqld; hdr = hdr left(outda.i.sqlname, 12); end
say hdr
do forever
  "EXECSQL FETCH C2 USING DESCRIPTOR :OUTDA"
  if sqlcode = 100 then leave
  if sqlcode < 0 then signal sqlerr
  line = ''
  do i = 1 to outda.sqld
    if outda.i.sqlind < 0 then v = '-null-'; else v = outda.i.sqldata
    line = line left(v, 12)
  end
  say line
end
"EXECSQL CLOSE C2"

/* --- input SQLDA ----------------------------------------------------------- */
ins = 'INSERT INTO EMP (EMPNO, NAME, DEPT, SALARY, HIRED) VALUES (?, ?, ?, ?, ?)'
"EXECSQL PREPARE S2 FROM :ins"
"EXECSQL DESCRIBE INPUT S2 INTO :INDA"
say 'input parameters:' inda.sqld
do i = 1 to inda.sqld; say '  param' i 'type' inda.i.sqltype typename(inda.i.sqltype); end
vals = '000070 PULASKI D21 36170.00 NULL'
do i = 1 to inda.sqld
  inda.i.sqldata = word(vals, i)
  inda.i.sqlind  = 0
  if inda.i.sqldata = 'NULL' then inda.i.sqlind = -1
end
"EXECSQL DELETE FROM EMP WHERE EMPNO = '000070'"
"EXECSQL EXECUTE S2 USING DESCRIPTOR :INDA"
if sqlcode < 0 then signal sqlerr
say 'inserted with descriptor, SQLERRD.3 =' sqlerrd.3
"EXECSQL SELECT NAME, HIRED INTO :nm, :hd :hdi FROM EMP WHERE EMPNO = '000070'"
say 'read back:' nm 'hired indicator' hdi
"EXECSQL ROLLBACK"
address dsnrexx 'DISCONNECT'
exit 0

typename: procedure
  t = arg(1) % 2 * 2
  select
    when t = 448 then return 'VARCHAR'
    when t = 452 then return 'CHAR'
    when t = 484 then return 'DECIMAL'
    when t = 496 then return 'INTEGER'
    when t = 500 then return 'SMALLINT'
    when t = 492 then return 'BIGINT'
    when t = 480 then return 'FLOAT'
    when t = 384 then return 'DATE'
    when t = 388 then return 'TIME'
    when t = 392 then return 'TIMESTAMP'
    otherwise return 'OTHER'
  end

sqlerr:
  say 'SQLCODE' sqlcode 'at line' sigl
  call dsntiar 'MSG.'
  do m = 1 to msg.0; say msg.m; end
  exit 12
