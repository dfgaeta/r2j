/* REXX - dsn4: configuration file + SET JDBC + CALL/SET host variable + JCALL */
say 'config file :' cfg('report', 'title')
say 'APPL from [vars]:' appl '  argument:' arg(1)
/* explicit JDBC URL (instead of CONNECT ssid) */
address dsnrexx "SET JDBC jdbc:hsqldb:mem:demo;sql.syntax_db2=true SA"
address dsnrexx "CONNECT"
address dsnrexx "EXECSQL SET :today = CURRENT DATE"
say 'CURRENT DATE via SET :hv =' today 'SQLCODE' sqlcode
address dsnrexx "EXECSQL EXECUTE IMMEDIATE CREATE TABLE T (ID INT, TXT VARCHAR(20))"
do i = 1 to 3
  t = 'line' i
  address dsnrexx "EXECSQL INSERT INTO T VALUES (:i, :t)"
end
address dsnrexx "EXECSQL SELECT COUNT(*) INTO :c FROM T"
say 'rows in T:' c
address dsnrexx 'DISCONNECT'
/* dynamic Java: alias hello -> JHello (compiled from ./java on first use) */
address jcall 'hello Dan "two words" 3'
say 'JCALL rc='rc 'result='result 'var set by Java:' jvar
address jcall 'Report' cfg('report', 'width')
say 'Report rc='rc
exit 0
