/** ADDRESS JSONX : r2j.Json + comando VALID jsonvar  (RC 0 valido / 8 invalido) */
public class JsonX extends r2j.Json {
    @Override
    public int hce(String host, String command) {
        String[] w = command.trim().split("\\s+");
        if (w.length == 2 && w[0].equalsIgnoreCase("VALID")) {
            String t = pool.get(w[1]);
            try {
                P p = new P(t == null ? "" : t, 0);
                p.value(); p.ws();
                if (p.i < p.s.length()) throw p.err("extra text");
                pool.set("JSONMSG", "");
                return 0;
            } catch (RuntimeException e) {
                pool.set("JSONMSG", e.getMessage());
                return 8;
            }
        }
        return super.hce(host, command);
    }
}
