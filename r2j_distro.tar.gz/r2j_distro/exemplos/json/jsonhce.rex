/* REXX - jsonhce : HCE dinamico (hce.js / hce.jsonx do rexx.cfg)          */
call show 'JSON'; call show 'JS'; call show 'JSONX'; call show 'NAOHA'
a = 1; b = 'x'
address js "BUILD a, b TO s"
say 'JS    ->' s
ok = '{"k":[1,2]}'; ko = '{"k":[1,2}'
address jsonx "VALID ok";  say 'VALID ok rc='rc
address jsonx "VALID ko";  say 'VALID ko rc='rc '-' jsonmsg
address jsonx "PARSE ok";  say 'JSONX PARSE k.0='k.0 k.1 k.2
exit
show: parse arg e
  address tso "SUBCOM" e
  say left(e, 6) 'SUBCOM rc='rc
  return
