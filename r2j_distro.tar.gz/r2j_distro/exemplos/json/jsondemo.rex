/* REXX - jsondemo : ADDRESS JSON  (BUILD / PARSE / METADATA)              */
address json

/* ---------------------------------------------------- BUILD ----------- */
nome   = 'Ana Souza'
idade  = 34
saldo  = 1250.75
cep    = '01310100'
zip    = '007'                        /* nao e numero JSON: fica string  */
fones.0 = 2; fones.1 = '11 5555-1234'; fones.2 = '11 9999-0000'
itens.0 = 2
itens.1.prod = 'Caneta'; itens.1.qtd = 10; itens.1.preco = 2.5
itens.2.prod = 'Caderno'; itens.2.qtd = 3; itens.2.preco = 18.9
end.rua = 'Av Paulista'; end.numero = 1000
drop nada

"BUILD nome, idade, saldo, cep, zip, fones., itens., end.rua, end.numero, nada TO js"
say 'BUILD rc='rc 'membros='jsoncnt
say js
"BUILD nome, itens. TO jp PRETTY"
say jp

/* ---------------------------------------------------- PARSE ----------- */
drop nome idade fones. itens.
txt = '{"cliente":"Bruno","ativo":true,"bloqueado":false,"obs":null,',
      '"limite":5e3,"tags":["vip","novo"],',
      '"pedido":{"numero":123,"itens":[{"sku":"A1","qtd":2},{"sku":"B7","qtd":1}]},',
      '"nome completo":"Bruno \"Bebeto\" LimaA"}'
"PARSE txt"
say 'PARSE rc='rc 'variaveis='jsoncnt
say 'cliente     =' cliente
say 'ativo/bloq  =' ativo'/'bloqueado '  obs=['obs']  limite='limite '-> x2 =' limite*2
say 'tags        =' tags.0 '->' tags.1',' tags.2
say 'pedido      =' pedido.numero 'itens='pedido.itens.0
do i = 1 to pedido.itens.0
   say '   item' i':' pedido.itens.i.sku 'qtd' pedido.itens.i.qtd
end
say 'nome_completo =' nome_completo

/* round trip: o JSON parseado volta a ser montado */
"BUILD cliente, tags., pedido. TO volta"
say 'volta =' volta

/* PARSE com prefixo, e de literal JSON / array no topo */
/* atencao (regra REXX): em c.cliente o tail e o VALOR da variavel CLIENTE */
/* se ela existir -> drop cliente antes de usar c.cliente                   */
"PARSE txt INTO c."
drop cliente
say 'c.cliente =' c.cliente '  c.pedido.itens.2.sku =' c.pedido.itens.2.sku
address json 'PARSE [10, 20, 30.5]'
say 'json.0 =' json.0 '->' json.1 json.2 json.3

/* ---------------------------------------------------- METADATA -------- */
"METADATA txt TO meta."
say 'METADATA rc='rc 'itens='meta.0
do i = 1 to meta.0
   parse var meta.i var '|' tipo '|' conteudo
   say left(var, 24) left(tipo, 8) conteudo
end

/* ---------------------------------------------------- erros ----------- */
bad = '{"a":1,}'
"PARSE bad"
say 'PARSE invalido rc='rc '-' jsonmsg
"PARSE naoexiste"
say 'variavel ausente rc='rc '-' jsonmsg
"XPTO 1"
say 'comando invalido rc='rc '-' jsonmsg
exit 0
