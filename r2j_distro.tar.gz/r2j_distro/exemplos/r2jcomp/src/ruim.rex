/* REXX - programa com erro de sintaxe */
do i = 1 to 3
  say i
