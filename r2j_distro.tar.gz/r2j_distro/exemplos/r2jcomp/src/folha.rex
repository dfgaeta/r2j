/* REXX - folha: exemplo de programa sob controle do r2jcomp */
parse arg salario .
if salario = '' then salario = 1000
say 'salario' salario 'liquido' format(salario * 0.89, , 2)
exit 0
