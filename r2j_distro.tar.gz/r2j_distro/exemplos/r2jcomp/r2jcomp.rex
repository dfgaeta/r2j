/* REXX ----------------------------------------------------------------------
 * r2jcomp - controle de compilacao de programas REXX (r2j) com controle de
 *           fonte e versoes vv.rr
 *
 * Uso:  r2jcomp                          interativo (paineis ISPF)
 *       r2jcomp COMP prog [R|V|F] [comentario]   compila; RC=0 -> nova versao
 *       r2jcomp HIST prog                historico de versoes
 *       r2jcomp LIST                     programas sob controle
 *       r2jcomp REST prog vv.rr          restaura a versao para o dir. de fontes
 *       r2jcomp DIFF prog [vv.rr]        diferencas fonte atual x versao
 *
 * Compilacao = r2j (REXX -> Java, gera .java e .map) + javac.
 * Com RC=0 o fonte e o mapa de compilacao sao copiados para
 *     <repo>/<prog>.Vvv.rr/      (ex.: versions/folha.V01.03/)
 * Versao: primeira = 01.00; R (padrao) = release+1 (rr 00..99, 99 -> vv+1);
 *         V = versao+1 e release 00; F = gera versao mesmo sem alteracao no fonte.
 * Se o fonte nao mudou desde a ultima versao, nenhuma versao nova e' criada.
 * Historico em SQLite (ADDRESS SQLITE): tabelas VERSIONS e COMPILES.
 * Configuracao: secao [r2jcomp] do r2jcomp.cfg / rexx.cfg.
 * ------------------------------------------------------------------------- */
parse arg verb prog rest
cp     = cfg('r2jcomp', 'classpath', '.')
srcdir = cfg('r2jcomp', 'src', '.')
outdir = cfg('r2jcomp', 'out', './bin')
repo   = cfg('r2jcomp', 'repo', './versions')
dbfile = cfg('r2jcomp', 'db', './r2jcomp.db')
mode   = translate(cfg('r2jcomp', 'mode', 'MAIN'))
java   = cfg('r2jcomp', 'java', 'java')
javac  = cfg('r2jcomp', 'javac', 'javac')
usr    = userid()

call dbopen
verb = translate(verb)
select
  when verb = '' then call interactive
  when verb = 'COMP' | verb = 'COMPILE' then do
    parse var rest tipo nota
    if length(tipo) > 1 then do; nota = rest; tipo = 'R'; end
    crc = compile(prog, tipo, nota)
    do i = 1 to msgs.0; say msgs.i; end
    call dbclose
    exit crc
  end
  when verb = 'HIST' then do
    call history prog
    do i = 1 to hist.0; say hist.i; end
  end
  when verb = 'LIST' then do
    call listprogs
    do i = 1 to lst.0; say lst.i; end
  end
  when verb = 'REST' | verb = 'RESTORE' then do
    crc = restore(prog, word(rest, 1))
    say msg
    call dbclose
    exit crc
  end
  when verb = 'DIFF' then do
    call diff prog, word(rest, 1)
    do i = 1 to dif.0; say dif.i; end
  end
  otherwise say 'r2jcomp: comando invalido' verb '(COMP HIST LIST REST DIFF)'
end
call dbclose
exit 0

/* ------------------------------------------------------------------ banco */
dbopen:
  address sqlite 'CONNECT' dbfile
  if sqlcode <> 0 then do; say 'r2jcomp: erro abrindo' dbfile sqlerrmc; exit 12; end
  address sqlite
  'CREATE TABLE IF NOT EXISTS VERSIONS (PROG TEXT, VV INTEGER, RR INTEGER, VERSION TEXT,',
    'DT TEXT, HR TEXT, USR TEXT, LINES INTEGER, DIR TEXT, NOTE TEXT, PRIMARY KEY (PROG, VV, RR))'
  'CREATE TABLE IF NOT EXISTS COMPILES (PROG TEXT, DT TEXT, HR TEXT, USR TEXT, RC INTEGER, VERSION TEXT, MSG TEXT)'
  address
  return

dbclose:
  address sqlite 'DISCONNECT'
  return

/* ------------------------------------------------------------------ compilacao */
compile: procedure expose cp srcdir outdir repo mode java javac usr msgs. lastrc
  parse arg prog, tipo, nota
  prog = strip(prog); tipo = translate(strip(tipo))
  if tipo = '' then tipo = 'R'
  msgs.0 = 0
  if prog = '' then return erro('programa nao informado')
  if pos(tipo, 'RVF') = 0 then return erro('tipo invalido' tipo '(R V F)')
  src = srcdir'/'prog'.rex'
  if stream(src, 'C', 'QUERY EXISTS') = '' then return erro('fonte nao encontrado:' src)
  call mkdir outdir
  log = outdir'/'prog'.log'
  /* 1) r2j: REXX -> Java + mapa de compilacao */
  opt = ''
  if mode = 'ISPF' then opt = '-ispf'
  address system java '-cp "'cp'" r2j "'src'" -o "'outdir'"' opt '>"'log'" 2>&1'
  rc1 = rc
  /* 2) javac */
  rc2 = 0
  if rc1 = 0 then do
    address system javac '-nowarn -cp "'cp'" -d "'outdir'" "'outdir'/'prog'.java" >>"'log'" 2>&1'
    rc2 = rc
  end
  lastrc = max(rc1, rc2)
  call note 'compilacao de' prog': r2j RC='rc1 'javac RC='rc2
  ver = ''
  if lastrc = 0 then do
    /* 3) controle de versao */
    lvv = 0; lrr = -1; ldir = ''
    address sqlite "SELECT VV, RR, DIR INTO :lvv, :lrr, :ldir FROM VERSIONS WHERE PROG = :prog",
                   "ORDER BY VV DESC, RR DESC LIMIT 1"
    existe = (sqlcode = 0)
    if existe & tipo <> 'F' & tipo <> 'V' then do
      if readfile(src) == readfile(ldir'/'prog'.rex') then do
        ver = fmtver(lvv, lrr)
        call note 'fonte sem alteracoes desde a versao' ver '- nenhuma versao nova'
        call logcomp prog, lastrc, ver, 'sem alteracoes'
        return 0
      end
    end
    select
      when \existe then do; vv = 1; rr = 0; end
      when tipo = 'V' then do; vv = lvv + 1; rr = 0; end
      otherwise do
        vv = lvv; rr = lrr + 1
        if rr > 99 then do; vv = vv + 1; rr = 0; end
      end
    end
    ver = fmtver(vv, rr)
    dir = repo'/'prog'.V'ver
    call mkdir dir
    call copyfile src, dir'/'prog'.rex'
    call copyfile outdir'/'prog'.map', dir'/'prog'.map'
    call copyfile log, dir'/'prog'.log'
    linhas = countlines(src)
    dt = date('I'); hr = time()
    address sqlite "INSERT INTO VERSIONS VALUES (:prog, :vv, :rr, :ver, :dt, :hr, :usr, :linhas, :dir, :nota)"
    if sqlcode <> 0 then call note 'erro gravando versao:' sqlcode sqlerrmc
    call note 'versao' ver 'criada em' dir '('linhas 'linhas)'
  end
  else do
    call note 'compilacao com erro - nenhuma versao gerada; veja' log
    call lastlines log, 12
  end
  call logcomp prog, lastrc, ver, nota
  return lastrc

fmtver: procedure
  return right(arg(1), 2, '0')'.'right(arg(2), 2, '0')

note:
  n = msgs.0 + 1; msgs.n = arg(1); msgs.0 = n
  return

erro:
  call note 'r2jcomp:' arg(1)
  lastrc = 16
  return 16

logcomp: procedure expose usr
  parse arg p, r, v, m
  dt = date('I'); hr = time()
  address sqlite "INSERT INTO COMPILES VALUES (:p, :dt, :hr, :usr, :r, :v, :m)"
  return

lastlines: procedure expose msgs.
  parse arg f, n
  t. = ''; k = 0
  do while lines(f) > 0
    k = k + 1; t.k = linein(f)
  end
  call lineout f
  do i = max(1, k - n + 1) to k; call note '  |' t.i; end
  return

/* ------------------------------------------------------------------ arquivos */
mkdir: procedure
  address system 'mkdir -p "'arg(1)'"'
  return rc

readfile: procedure
  parse arg f
  if stream(f, 'C', 'QUERY EXISTS') = '' then return '00'x
  d = charin(f, 1, chars(f))
  call charout f
  return d

copyfile: procedure
  parse arg de, para
  if stream(de, 'C', 'QUERY EXISTS') = '' then return 4
  d = readfile(de)
  call stream para, 'C', 'OPEN WRITE REPLACE'
  call charout para, d
  call charout para
  return 0

countlines: procedure
  parse arg f
  n = 0
  do while lines(f) > 0; call linein f; n = n + 1; end
  call lineout f
  return n

/* ------------------------------------------------------------------ consultas */
history: procedure expose hist. hrows.
  parse arg prog
  address sqlite "SELECT VERSION, DT, HR, USR, LINES, NOTE, DIR FROM VERSIONS WHERE PROG = :prog ORDER BY VV DESC, RR DESC"
  hist.0 = 0; hrows.0 = 0
  if sqlcode <> 0 then do; hist.1 = 'sem versoes para' prog; hist.0 = 1; return; end
  hist.1 = left('VERSAO',7) left('DATA',10) left('HORA',8) left('USUARIO',8) right('LINHAS',6) ' COMENTARIO'
  do i = 1 to version.0
    k = i + 1
    hist.k = left(version.i,7) left(dt.i,10) left(hr.i,8) left(usr.i,8) right(lines.i,6) ' 'note.i
    hrows.i = version.i dt.i hr.i usr.i lines.i '|' note.i
  end
  hist.0 = version.0 + 1; hrows.0 = version.0
  return

listprogs: procedure expose lst.
  address sqlite "SELECT PROG, MAX(VV*100+RR) AS VR, COUNT(*) AS N, MAX(DT) AS DT FROM VERSIONS GROUP BY PROG ORDER BY PROG"
  lst.0 = 0
  if sqlcode <> 0 then do; lst.1 = 'nenhum programa sob controle'; lst.0 = 1; return; end
  lst.1 = left('PROGRAMA',10) left('VERSAO',7) left('DATA',10) 'VERSOES'
  do i = 1 to prog.0
    k = i + 1
    lst.k = left(prog.i,10) left(right(vr.i % 100,2,'0')'.'right(vr.i // 100,2,'0'),7) left(dt.i,10) n.i
  end
  lst.0 = prog.0 + 1
  return

restore: procedure expose srcdir msg usr
  parse arg prog, ver
  address sqlite "SELECT DIR INTO :dir FROM VERSIONS WHERE PROG = :prog AND VERSION = :ver"
  if sqlcode <> 0 then do; msg = 'versao' ver 'de' prog 'nao encontrada'; return 8; end
  src = srcdir'/'prog'.rex'
  if stream(src, 'C', 'QUERY EXISTS') <> '' then do
    bak = srcdir'/'prog'.rex.bak'
    call copyfile src, bak
  end
  call copyfile dir'/'prog'.rex', src
  msg = 'versao' ver 'restaurada em' src '(copia anterior em' prog'.rex.bak)'
  call logcomp prog, 0, ver, 'restore'
  return 0

diff: procedure expose srcdir dif.
  parse arg prog, ver
  if ver = '' then address sqlite "SELECT DIR, VERSION INTO :dir, :ver FROM VERSIONS WHERE PROG = :prog ORDER BY VV DESC, RR DESC LIMIT 1"
  else address sqlite "SELECT DIR INTO :dir FROM VERSIONS WHERE PROG = :prog AND VERSION = :ver"
  dif.0 = 0
  if sqlcode <> 0 then do; dif.1 = 'versao nao encontrada'; dif.0 = 1; return; end
  tmp = srcdir'/.r2jcomp.diff'
  address system 'diff "'dir'/'prog'.rex" "'srcdir'/'prog'.rex" >"'tmp'" 2>&1'
  drc = rc
  n = 1; dif.1 = '--- versao' ver '(<)  x  fonte atual (>)  diff RC='drc
  do while lines(tmp) > 0; n = n + 1; dif.n = linein(tmp); end
  call lineout tmp
  if drc = 0 then do; n = n + 1; dif.n = '(sem diferencas)'; end
  dif.0 = n
  return

/* ------------------------------------------------------------------ interativo */
interactive:
  address ispexec
  "CONTROL ERRORS RETURN"
  srcdir = srcdir
  zmsg = 'Informe o programa e o comando'
  t = 'R'
  do forever
    call refresh
    "DISPLAY PANEL(RCOMP01)"
    if rc > 4 then leave
    parse var zcmd cmd parm
    cmd = translate(cmd); zcmd = ''
    zmsg = ''
    prog = strip(prog)
    if cmd = '' then iterate
    if prog = '' & cmd <> 'LIST' then do; zmsg = 'Informe o programa'; iterate; end
    select
      when cmd = 'COMP' then do
        address ispexec
        rc = compile(prog, t, nota)
        zmsg = msgs.1
        do i = 2 to msgs.0; zmsg = zmsg '/' msgs.i; end
        if lastrc <> 0 then do
          lg. = ''; lg.0 = 0; f = outdir'/'prog'.log'; k = 0
          do while lines(f) > 0; k = k + 1; lg.k = linein(f); end
          call lineout f; lg.0 = k
          "VIEW STEM(LG)"
        end
      end
      when cmd = 'EDIT' then do
        "EDIT DATASET('"srcdir'/'prog".rex')"
        if rc = 0 then zmsg = 'fonte gravado'; else zmsg = 'fonte nao alterado'
      end
      when cmd = 'LOG' then do
        "VIEW DATASET('"outdir'/'prog".log')"
        if rc > 4 then zmsg = 'log nao encontrado'
      end
      when cmd = 'HIST' then call histpanel prog
      when cmd = 'LIST' then call listpanel
      when cmd = 'REST' then do
        rc = restore(prog, word(parm, 1)); zmsg = msg
      end
      otherwise zmsg = 'Comando invalido:' cmd
    end
  end
  return

refresh:
  lastver = ''; lastdt = ''; lastusr = ''; lastdir = ''; lastcmp = ''; lastrc = ''
  if prog = '' then return
  address sqlite "SELECT VERSION, DT, USR, DIR INTO :lastver, :lastdt, :lastusr, :lastdir FROM VERSIONS",
                 "WHERE PROG = :prog ORDER BY VV DESC, RR DESC LIMIT 1"
  address sqlite "SELECT DT || ' ' || HR, RC INTO :lastcmp, :lastrc FROM COMPILES WHERE PROG = :prog",
                 "ORDER BY rowid DESC LIMIT 1"
  return

histpanel:
  parse arg hprog
  call history hprog
  "TBCREATE RCHIST NAMES(VERSION DT HR USR LINES NOTE) NOWRITE REPLACE"
  do i = 1 to hrows.0
    parse var hrows.i version dt hr usr lines '|' note
    "TBADD RCHIST"
  end
  "TBTOP RCHIST"
  zmsg = hrows.0 'versoes'
  "TBDISPL RCHIST PANEL(RCOMP02)"
  do while rc <= 4
    if ztdsels > 0 then do
      dir = repo'/'hprog'.V'version
      select
        when sel = 'S' then "VIEW DATASET('"dir'/'hprog".rex')"
        when sel = 'M' then "VIEW DATASET('"dir'/'hprog".map')"
        when sel = 'R' then do; call restore hprog, version; zmsg = msg; end
        when sel = 'D' then do; call diff hprog, version; "VIEW STEM(DIF)"; end
        otherwise zmsg = 'Selecao invalida:' sel
      end
      if ztdsels > 1 then do; "TBDISPL RCHIST"; iterate; end
    end
    "TBDISPL RCHIST PANEL(RCOMP02)"
  end
  if rc > 8 then zmsg = 'TBDISPL RC='rc zerrlm; else zmsg = ''
  "TBEND RCHIST"
  return

listpanel:
  address sqlite "SELECT PROG, MAX(VV*100+RR) AS VR, COUNT(*) AS N, MAX(DT) AS DT, MAX(USR) AS U FROM VERSIONS GROUP BY PROG ORDER BY PROG"
  "TBCREATE RCLIST NAMES(PROG VERSION DT USR NVER) NOWRITE REPLACE"
  do i = 1 to sqlrecs
    lp = prog.i
    prog = lp; version = right(vr.i % 100,2,'0')'.'right(vr.i // 100,2,'0'); dt = dt.i; usr = u.i; nver = n.i
    "TBADD RCLIST"
  end
  "TBTOP RCLIST"
  sprog = ''
  "TBDISPL RCLIST PANEL(RCOMP03)"
  do while rc <= 4
    if ztdsels > 0 then do
      if sel = 'S' then sprog = prog
      if sel = 'H' then do; sprog = prog; call histpanel prog; end
      if ztdsels > 1 then do; "TBDISPL RCLIST"; iterate; end
      if sel = 'S' then leave
    end
    "TBDISPL RCLIST PANEL(RCOMP03)"
  end
  if rc > 8 then zmsg = 'TBDISPL RC='rc zerrlm
  "TBEND RCLIST"
  prog = sprog
  return
