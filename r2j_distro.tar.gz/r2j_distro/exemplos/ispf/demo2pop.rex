/* REXX - demo2pop: popup de confirmacao com ADDPOP/REMPOP (Demo2Popup)     */
/* No painel principal digite DEL no comando e ENTER; responda S ou N.      */
address ispexec
do forever
  "DISPLAY PANEL(PANL016)"
  if rc > 4 then leave
  if translate(zcmd) = 'DEL' then do
    zresp = ''
    "ADDPOP"
    "DISPLAY PANEL(PANL002)"                 /* WINDOW(60,9) centralizado */
    prc = rc
    "REMPOP"
    if prc = 0 & zresp = 'S' then zedsmsg = 'Registro excluido'
    else zedsmsg = 'Exclusao cancelada'
    zedlmsg = 'Resposta do popup: ZRESP='zresp
    "SETMSG MSG(ISRZ001)"
    zcmd = ''
  end
end
"VGET (ZRESP) SHARED"
say 'Ultima resposta do popup (ZRESP) =' zresp
exit 0
