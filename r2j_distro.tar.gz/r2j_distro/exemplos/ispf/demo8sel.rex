/* REXX - demo8sel: TBDISPL com coluna de selecao e ZTDSELS (S=mostrar D=excluir) */
address ispexec
"CONTROL ERRORS RETURN"
"TBOPEN CLIENTES WRITE"
if rc <> 0 then do; say 'execute demo7tb ou tbtest antes (TBOPEN RC='rc')'; exit 8; end
"TBSORT CLIENTES FIELDS(NOME,C,A)"
zmsg = ''
"TBTOP CLIENTES"
"TBDISPL CLIENTES PANEL(PANL015)"
do while rc <= 4
  if ztdsels > 0 then do
    select
      when sel = 'D' then do
        "TBDELETE CLIENTES"
        zmsg = 'Excluido' cod nome
      end
      when sel = 'S' then do
        zedsmsg = cod nome
        zedlmsg = 'Cidade:' cidade
        "SETMSG MSG(ISRZ001)"
      end
      otherwise zmsg = 'Selecao invalida:' sel
    end
    if ztdsels > 1 then do; "TBDISPL CLIENTES"; iterate; end
  end
  "TBDISPL CLIENTES PANEL(PANL015)"
end
"TBCLOSE CLIENTES"
exit 0
