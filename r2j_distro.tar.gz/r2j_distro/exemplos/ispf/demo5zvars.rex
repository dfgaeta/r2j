/* REXX - demo5zvars: placeholder Z resolvido por .ZVARS (Demo5)            */
address ispexec
campo1 = 'OLA'
campo2 = 'MUNDO'
do forever
  "DISPLAY PANEL(PANL012)"
  if rc > 4 then leave
end
say 'CAMPO1 =' campo1
say 'CAMPO2 =' campo2
say 'ECO1   =' eco1
say 'ECO2   =' eco2
exit 0
