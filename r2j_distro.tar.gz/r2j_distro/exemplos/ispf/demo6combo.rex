/* REXX - demo6combo: campos TYPE(CB) alimentados pelo stem <campo>.n (Demo6) */
pais.1 = 'BR Brasil'; pais.2 = 'US Estados Unidos'; pais.3 = 'PT Portugal'
pais.4 = 'AR Argentina'; pais.5 = 'JP Japao'; pais.0 = 5
status.1 = 'NOVO Novo pedido'; status.2 = 'PROC Em processamento'
status.3 = 'ENVI Enviado';     status.4 = 'CANC Cancelado'; status.0 = 4
pais = ''; status = ''
address ispexec "LIBDEF ISPMLIB ID(msgs)"
do forever
  address ispexec "DISPLAY PANEL(PANL013)"    /* ENTER num campo CB abre a lista */
  if rc > 4 then leave
end
say 'PAIS   =' pais
say 'STATUS =' status
say 'RESULT =' result
exit 0
