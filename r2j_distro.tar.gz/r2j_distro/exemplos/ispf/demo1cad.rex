/* REXX - demo1cad: painel de cadastro (baseado em Demo1Cadastro)            */
/* ISPEXEC DISPLAY com variaveis REXX pre-preenchidas, CURSOR(), )PROC VER  */
address ispexec
"LIBDEF ISPPLIB DATASET ID('panels')"        /* sem ID = diretorio corrente */
nome   = 'DAN DEV'
cidade = 'SAO PAULO'
csr    = 'NOME'
do forever
  "DISPLAY PANEL(PANL001) CURSOR("csr")"
  if rc > 4 then leave                       /* PF3/PF12 -> RC 8 */
  csr = 'ZCMD'
end
say 'Painel encerrado, ZPFKEY =' zpfkey
say 'NOME    =' nome
say 'ENDER   =' ender
say 'CIDADE  =' cidade
say 'UF      =' uf
say 'IDADE   =' idade
say 'RESULT  =' result
exit 0
