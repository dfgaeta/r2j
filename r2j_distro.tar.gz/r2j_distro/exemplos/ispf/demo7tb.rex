/* REXX - demo7tb: cadastro com servicos de tabela (Demo7TableService)      */
/* Comandos: ADD (TBMOD)  GET (TBSKIP)  TOP (TBTOP)  DEL (TBDELETE)  SAIR   */
address ispexec
"CONTROL ERRORS RETURN"
"LIBDEF ISPTLIB ID(tables)"
"LIBDEF ISPTABL ID(tables)"
"TBOPEN CLIENTES WRITE"                       /* mesma tabela do Demo7 (SQLite) */
if rc = 8 then "TBCREATE CLIENTES KEYS(COD) NAMES(NOME CIDADE) WRITE"
if rc > 4 then do; say 'TBOPEN/TBCREATE RC='rc zerrlm; exit 12; end
zmsg = ''
do forever
  "DISPLAY PANEL(PANL014)"
  if rc > 4 then leave
  cmd = translate(strip(zcmd)); zcmd = ''
  select
    when cmd = 'ADD' then do
      "TBMOD CLIENTES"; tbrc = rc
      zmsg = 'TBMOD RC='tbrc word('(atualizado) (incluido)', 1 + (tbrc = 8))
    end
    when cmd = 'GET' then do
      "TBSKIP CLIENTES"
      if rc = 0 then zmsg = 'TBSKIP RC=0'
      else zmsg = 'TBSKIP RC='rc '(fim de tabela)'
    end
    when cmd = 'TOP' then do; "TBTOP CLIENTES"; zmsg = 'TBTOP RC='rc; end
    when cmd = 'DEL' then do; "TBDELETE CLIENTES"; zmsg = 'TBDELETE RC='rc; end
    when cmd = 'SAIR' then leave
    when cmd = '' then nop
    otherwise zmsg = 'Comando desconhecido:' cmd
  end
end
"TBCLOSE CLIENTES"
say 'TBCLOSE RC='rc
"TBOPEN CLIENTES NOWRITE"
"TBQUERY CLIENTES ROWNUM(NUMROWS) KEYS(KEYS) NAMES(NAMES)"
say 'Total de linhas persistidas:' numrows 'chaves' keys 'nomes' names
"TBEND CLIENTES"
exit 0
