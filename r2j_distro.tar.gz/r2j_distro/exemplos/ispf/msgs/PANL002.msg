PANL002S 'Exclusao confirmada'
'O registro sera excluido'
PANL002N 'Exclusao cancelada'
'Nenhuma alteracao foi feita'
