PANL013K 'Pedido confirmado'
'Pais &PAIS status &STATUS'
