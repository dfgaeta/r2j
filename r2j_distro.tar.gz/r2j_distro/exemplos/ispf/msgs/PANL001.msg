PANL001X 'Comando SAIR recebido' .ALARM=YES
'Use PF3 para encerrar o cadastro de &NOME'
