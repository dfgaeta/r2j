/* REXX - tbtest: todos os servicos de tabela (roda sem terminal) */
falhas = 0
address ispexec
"CONTROL ERRORS RETURN"
call t "TBCREATE CLI2 KEYS(COD) NAMES(NOME CIDADE UF) WRITE REPLACE"
data = '0003 CARLOS LIMA;CURITIBA;PR|0001 MARIA SILVA;SAO PAULO;SP|0005 PEDRO ALVES;SANTOS;SP|0002 JOAO SOUZA;RIO DE JANEIRO;RJ|0004 ANA PEREIRA;RECIFE;PE'
do while data <> ''
  parse var data cod nome ';' cidade ';' uf '|' data
  obs = 'cliente' cod
  call t "TBADD CLI2 SAVE(OBS)"               /* OBS = variavel de extensao */
end
cod = '0001'; nome = 'X'; cidade = 'X'; uf = 'X'
call t "TBADD CLI2", 8                  /* chave duplicada */
call t "TBQUERY CLI2 KEYS(K) NAMES(N) ROWNUM(R) KEYNUM(KN) NAMENUM(NN) POSITION(P)"
say '   KEYS='k 'NAMES='n 'ROWNUM='r 'KEYNUM='kn 'NAMENUM='nn 'POSITION='p
cod = '0002'
call t "TBGET CLI2 POSITION(CRP) ROWID(RID)"
say '   TBGET 0002 ->' nome '/' cidade '/' uf 'OBS='obs 'CRP='crp 'ROWID='rid
cod = '9999'
call t "TBGET CLI2", 8
cod = '0004'
call t "TBEXIST CLI2"
cod = '0004'; nome = 'ANA PEREIRA COSTA'; cidade = 'OLINDA'; uf = 'PE'
call t "TBMOD CLI2"                           /* existe -> RC 0 */
cod = '0006'; nome = 'LUCIA REIS'; cidade = 'NATAL'; uf = 'RN'
call t "TBMOD CLI2", 8                  /* nova -> RC 8 */
call t "TBSORT CLI2 FIELDS(UF,C,A,NOME,C,D)"
call t "TBTOP CLI2"
say '   ordem UF asc, NOME desc:'
do forever
  "TBSKIP CLI2"
  if rc <> 0 then leave
  say '     ' cod left(nome,20) uf
end
call t "TBBOTTOM CLI2 POSITION(P)"
say '   TBBOTTOM ->' cod nome 'POSITION='p
call t "TBSKIP CLI2 NUMBER(-2)"
say '   TBSKIP -2 ->' cod nome
call t "TBSKIP CLI2 NUMBER(10)", 8
/* busca: TBSARG + TBSCAN */
call t "TBVCLEAR CLI2"
uf = 'SP'
call t "TBSARG CLI2"
call t "TBTOP CLI2"
say '   clientes de SP (TBSARG UF=SP):'
do forever
  "TBSCAN CLI2"
  if rc <> 0 then leave
  say '     ' cod nome
end
nome = 'J*'
call t "TBTOP CLI2"
call t "TBSCAN CLI2 ARGLIST(NOME) CONDLIST(EQ)"
say '   generico NOME=J* ->' cod nome
cod = '0003'
call t "TBTOP CLI2"
call t "TBSCAN CLI2 ARGLIST(COD) CONDLIST(GT)"
say '   primeiro COD > 0003 na ordem atual ->' cod nome
/* TBPUT na linha corrente */
cidade = 'ALTERADA'
call t "TBPUT CLI2"
cod = '0001'
call t "TBDELETE CLI2"
call t "TBDELETE CLI2", 8
call t "TBSTAT CLI2 STATUS1(S1) STATUS2(S2) ROWCURR(RC1) TABLEUPD(UPD)"
say '   STATUS1='s1 'STATUS2='s2 'ROWCURR='rc1 'TABLEUPD='upd
call t "TBCLOSE CLI2"
call t "TBOPEN CLI2 NOWRITE"
call t "TBQUERY CLI2 ROWNUM(R) SORTFLDS(SF)"
say '   reaberta: ROWNUM='r 'SORTFLDS='sf
cod = '0002'
call t "TBGET CLI2"
say '   extensao persistida: OBS='obs
call t "TBSAVE CLI2", 12                 /* NOWRITE */
call t "TBEND CLI2"
call t "TBERASE CLI2"
call t "TBOPEN CLI2", 8
call t "TBCLOSE NADA", 12
/* tabela do Demo7 (formato SQLite original) */
call t "TBOPEN CLIENTES NOWRITE"
if rc = 0 then do
  "TBQUERY CLIENTES ROWNUM(R) KEYS(K) NAMES(N)"
  say '   CLIENTES (Demo7):' r 'linhas' k n
  "TBEND CLIENTES"
end
say 'falhas:' falhas + 0
exit falhas + 0

/* sem PROCEDURE: os servicos ISPEXEC usam as variaveis do contexto corrente */
t:
  parse arg t_cmd, t_esp
  if t_esp = '' then t_esp = 0
  address ispexec t_cmd
  t_ok = rc = t_esp
  if \t_ok then falhas = falhas + 1
  say left(t_cmd, 62) 'RC='left(rc,2) word('FALHOU OK', t_ok + 1)
  return
