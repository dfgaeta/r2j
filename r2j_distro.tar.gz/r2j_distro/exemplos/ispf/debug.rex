/* REXX - debug: depurador interativo (TRACE ?R)                              */
/* tela: ENTER=passo  G=continua  B n=breakpoint  P var  X instrucao REXX       */
/*       PF9=variaveis por contexto (PF10/PF11 troca de contexto) PF3=fim depuracao */
arg n .
if n = '' then n = 5
lista. = ''
trace ?r
total = 0
do i = 1 to n
  lista.i = i * i
  total = total + lista.i
end
say 'soma dos quadrados ate' n '=' total
say 'fatorial de' n '=' fact(n)
call mostra 'fim'
exit 0

fact: procedure expose total
  parse arg k
  if k <= 1 then return 1
  return k * fact(k - 1)

mostra:
  parse arg msg
  say 'mostra:' msg 'total='total
  return
