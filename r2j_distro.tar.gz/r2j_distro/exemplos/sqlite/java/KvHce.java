import java.util.*;

/**
 * Host Command Environment dinamico: ADDRESS KV "<comando>"   ([hce] hce.kv = KvHce no rexx.cfg)
 *   PUT chave valor...   GET chave var   DEL chave   LIST stem.   COUNT var   CLEAR
 * Uma instancia por ambiente: o mapa sobrevive entre comandos.
 */
public class KvHce extends r2j {
    private final Map<String, String> kv = new TreeMap<>();

    @Override
    public int hce(String host, String command) {
        String[] w = command.trim().split("\\s+", 3);
        String verb = w[0].toUpperCase();
        switch (verb) {
            case "PUT":   if (w.length < 3) return 8; kv.put(w[1].toUpperCase(), w[2]); return 0;
            case "GET":   { String v = kv.get(w[1].toUpperCase()); if (v == null) return 4; pool.set(w.length > 2 ? w[2] : w[1], v); return 0; }
            case "DEL":   return kv.remove(w[1].toUpperCase()) == null ? 4 : 0;
            case "COUNT": pool.set(w.length > 1 ? w[1] : "RESULT", String.valueOf(kv.size())); return 0;
            case "CLEAR": kv.clear(); return 0;
            case "LIST": {
                List<String> l = new ArrayList<>();
                for (Map.Entry<String, String> e : kv.entrySet()) l.add(e.getKey() + "=" + e.getValue());
                pool.setStemList(w.length > 1 ? w[1] : "KV.", l);
                result = String.valueOf(l.size());
                return 0;
            }
            default:
                say("KV: comando desconhecido " + verb + " (host " + host + ", chamado por " + prog.name + ")");
                return -3;
        }
    }
}
