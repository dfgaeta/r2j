/* REXX - sqldemo: ADDRESS SQLITE com SQLCA compativel com DSNREXX (SQLCODE, SQLRECS, SQLAFFCT) */
address sqlite
"CONNECT"                                   /* [sqlite] db= do rexx.cfg */
call chk 'CONNECT'
"DROP TABLE IF EXISTS EMP"
"CREATE TABLE EMP (EMPNO CHAR(6) PRIMARY KEY, NAME VARCHAR(30) NOT NULL, DEPT CHAR(3), SALARY DECIMAL(9,2))"
call chk 'CREATE'
data = '000010 HAAS A00 52750|000020 THOMPSON B01 41250|000030 KWAN C01 38250|000050 GEYER E01 40175|000060 STERN D11 32250'
do while data <> ''
  parse var data empno name dept salary '|' data
  "INSERT INTO EMP VALUES (:empno, :name, :dept, :salary)"
  call chk 'INSERT' empno
end
say 'insert: SQLAFFCT='sqlaffct
/* consulta sem INTO: stems por coluna + SQLRECS */
"SELECT EMPNO, NAME, SALARY FROM EMP WHERE SALARY > 35000 ORDER BY SALARY DESC"
say 'SELECT: SQLCODE='sqlcode 'SQLRECS='sqlrecs 'SQLCOLS='sqlcols
do i = 1 to empno.0; say ' ' empno.i left(name.i,10) salary.i; end
/* SELECT INTO */
"SELECT COUNT(*), SUM(SALARY) INTO :cnt, :tot FROM EMP"
say 'INTO: cnt='cnt 'tot='tot 'SQLRECS='sqlrecs
/* UPDATE / DELETE com SQLAFFCT */
pct = 1.10; dpat = 'C%'
"UPDATE EMP SET SALARY = SALARY * :pct WHERE DEPT LIKE :dpat OR DEPT = 'E01'"
say 'UPDATE: SQLCODE='sqlcode 'SQLAFFCT='sqlaffct 'SQLERRD.3='sqlerrd.3
"DELETE FROM EMP WHERE DEPT = 'ZZZ'"
say 'DELETE sem linhas: RC='rc 'SQLCODE='sqlcode 'SQLAFFCT='sqlaffct
/* cursor estilo DSNREXX */
sel = 'SELECT EMPNO, NAME FROM EMP WHERE SALARY < ? ORDER BY EMPNO'
"EXECSQL DECLARE C1 CURSOR FOR S1"
"EXECSQL PREPARE S1 FROM :sel"
lim = 42000
"EXECSQL OPEN C1 USING :lim"
do forever
  "EXECSQL FETCH C1 INTO :e, :n"
  if sqlcode <> 0 then leave
  say '  fetch' sqlrecs':' e n
end
say 'fim do cursor: SQLCODE='sqlcode 'SQLRECS='sqlrecs
"EXECSQL CLOSE C1"
/* DESCRIBE + FETCH USING DESCRIPTOR */
"EXECSQL PREPARE S2 INTO :DA FROM 'SELECT * FROM EMP'"
say 'DESCRIBE:' da.sqld 'colunas'
do i = 1 to da.sqld; say '  ' da.i.sqlname da.i.sqltype da.i.sqllen da.i.sqldecltype; end
/* erros -> SQLCODE DB2 */
address sqlite "SELECT X FROM NADA"
say 'erro 1: RC='rc 'SQLCODE='sqlcode 'SQLSTATE='sqlstate 'MSG='sqlerrmc
address sqlite "INSERT INTO EMP VALUES ('000010','DUP','A00',1)"
say 'erro 2: SQLCODE='sqlcode sqlerrmc
address sqlite "INSERT INTO EMP (EMPNO) VALUES ('000099')"
say 'erro 3: SQLCODE='sqlcode sqlerrmc
address sqlite "SELEC * FROM EMP"
say 'erro 4: SQLCODE='sqlcode
call dsntiar 'MSG.', 72
do i = 1 to msg.0; say msg.i; end
address sqlite "SELECT NAME INTO :x FROM EMP"
say 'erro 5: SQLCODE='sqlcode 'SQLRECS='sqlrecs
address sqlite "SELECT NAME INTO :x FROM EMP WHERE 1=0"
say 'vazio : SQLCODE='sqlcode 'RC='rc
address sqlite ".tables"
say 'dot command .tables:' sqlout.1
/* HCE dinamico */
address kv "PUT cliente MARIA SILVA"
address kv "PUT cidade SAO PAULO"
address kv "GET cliente quem"
address kv "COUNT n"
address kv "LIST kv."
say 'HCE KV: quem='quem 'n='n 'rc='rc 'result='result 'kv.1='kv.1
address kv "XYZ"
say 'HCE KV comando invalido rc='rc
address system 'SUBCOM KV'; say 'SUBCOM KV rc='rc
address sqlite "DISCONNECT"
exit 0

chk:
  if sqlcode < 0 then do; say 'ERRO' arg(1) sqlcode sqlerrmc; exit 8; end
  return
