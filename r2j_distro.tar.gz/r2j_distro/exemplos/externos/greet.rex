/* REXX */
parse arg who
parse source . how .
say 'Hello,' who '(called as' how')'
return 'greeted' who
