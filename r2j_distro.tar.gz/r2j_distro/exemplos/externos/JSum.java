import java.math.BigDecimal;
public class JSum implements r2j.RexxFunction {
    public String call(r2j.RexxProgram caller, String[] a) {
        BigDecimal t = BigDecimal.ZERO;
        for (String s : a) t = t.add(new BigDecimal(s));
        return caller.fmt(t);
    }
}
