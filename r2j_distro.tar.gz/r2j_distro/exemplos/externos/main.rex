/* REXX - main: external calls */
say 'square(9) =' square(9)          /* external REXX, translated with -r */
call greet 'Dan'                      /* external REXX, interpreted at run time (REXX map) */
say 'greet result:' result
say 'reverse via Java FUNC:' jrev('abcdef')
say 'sum via Java FUNC:' jsum(1, 2, 3.5)
say 'util:' util('x', 'y')            /* found as util.rex - translated with -r */
queue 'line from main'
call reader
say 'queued after reader' queued()
address tso "ALLOC FI(OUTDD) DA('out.txt') SHR"
do i = 1 to 3; o.i = 'record' i; end; o.0 = 3
address tso "EXECIO * DISKW OUTDD (STEM O. FINIS"
say 'execio write rc' rc
address tso "EXECIO * DISKR OUTDD (STEM IN. FINIS"
say 'execio read rc' rc 'lines' in.0 '->' in.1 '|' in.3
call lineout 'stream.txt', 'first'
call lineout 'stream.txt', 'second'
call lineout 'stream.txt'
do while lines('stream.txt') > 0
  say 'linein:' linein('stream.txt')
end
say 'exists:' (stream('stream.txt','C','QUERY EXISTS') <> '') 'size' stream('stream.txt','C','QUERY SIZE')
'echo shell says hi'
say 'shell rc' rc
address sh 'exit 0'
address command
'false'
say 'false rc' rc
exit
