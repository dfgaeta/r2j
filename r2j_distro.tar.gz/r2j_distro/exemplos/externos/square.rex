/* REXX */
parse arg n
return n * n
