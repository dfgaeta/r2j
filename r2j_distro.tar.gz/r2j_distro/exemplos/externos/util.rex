/* REXX */
return arg(1) || '+' || arg(2) '(args='arg()')'
