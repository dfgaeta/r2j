/* REXX */
pull l
say 'reader pulled:' l
push 'pushed'
queue 'queued'
