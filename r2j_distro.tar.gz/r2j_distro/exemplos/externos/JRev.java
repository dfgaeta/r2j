public class JRev implements r2j.RexxFunction {
    public String call(r2j.RexxProgram caller, String[] a) {
        caller.pool().set("JREV_CALLED", "yes");
        return new StringBuilder(a[0]).reverse().toString();
    }
}
