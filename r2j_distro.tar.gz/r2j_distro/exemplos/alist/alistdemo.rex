/* REXX - alistdemo : builtin ALIST (listas nomeadas sobre ArrayList)     */
say 'create     =' alist('create', 'clientes')       /* 0 = criada        */
say 'create  2x =' alist('create', 'Clientes')       /* 1 = ja existe     */
call alist 'add', 'clientes', 'Ana'
call alist 'add', 'clientes', 'Bruno'
say 'add        =' alist('add', 'clientes', 'Carla') /* itemid do novo    */
say 'ins        =' alist('ins', 'clientes', 1, 'Aaron')
say 'set (velho)=' alist('set', 'clientes', 3, 'Bruno Lima')
say 'del (item) =' alist('del', 'clientes', 4)
say 'cnt        =' alist('cnt', 'clientes')
call lista 'clientes'

/* load: lista nova e criada; lista existente recebe a partir do itemid */
say 'load novo  =' alist('load', 'texto', 'entrada.txt')
say 'load em 2  =' alist('load', 'clientes', 'entrada.txt', 2)
say 'load erro  =' alist('load', 'x', 'naoexiste.txt')
call lista 'clientes'

/* save inteiro e parcial (itemid inicio, qtd) */
say 'save tudo  =' alist('save', 'clientes', 'saida/tudo.txt')
say 'save 2,3   =' alist('save', 'clientes', 'saida/parte.txt', 2, 3)
call alist 'create', 'parte'
call alist 'load', 'parte', 'saida/parte.txt'
call lista 'parte'

/* rotina externa (sub.rex) enxerga as mesmas listas */
call sub 'clientes'
say 'apos sub cnt =' alist('cnt', 'clientes') '->' alist('get', 'clientes', alist('cnt', 'clientes'))

/* dump: lista de listas */
say 'dump       =' alist('dump', 'l.')
do i = 1 to l.0
   parse var l.i nome qtd
   say '   ' left(nome, 10) right(qtd, 4)
end
say 'destroy    =' alist('destroy', 'texto') alist('destroy', 'texto')

/* erros (itemid fora da faixa, lista inexistente) -> SYNTAX 40 */
signal on syntax name erro1
x = alist('get', 'clientes', 99)
erro1: say 'erro' rc':' condition('D')
signal on syntax name erro2
x = alist('cnt', 'nada')
erro2: say 'erro' rc':' condition('D')
exit 0

lista: procedure
  parse arg nm
  say '  ['nm']' alist('cnt', nm) 'itens'
  do i = 1 to alist('cnt', nm)
     say '    ' right(i, 2) alist('get', nm, i)
  end
  return
