/* REXX - sub : rotina externa usando a lista do chamador */
parse arg nm
call alist 'add', nm, 'Inserido por SUB'
return
