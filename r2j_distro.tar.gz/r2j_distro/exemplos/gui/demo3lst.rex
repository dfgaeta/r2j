/* REXX - demo3lst: listagem rolavel com )MODEL via TBDISPL (Demo3Listagem) */
address gui
"TBCREATE PRODUTOS NAMES(COD DESC QTDE STAT) NOWRITE REPLACE"
do i = 1 to 50
  cod  = right(i, 4, '0')
  desc = 'PRODUTO DE EXEMPLO NUMERO' i
  qtde = (i * 7) // 100
  if i // 3 = 0 then stat = 'BAIXO'; else stat = 'OK'
  "TBADD PRODUTOS"
end
"TBTOP PRODUTOS"
do forever
  "TBDISPL PRODUTOS PANEL(PANL003)"        /* PF7/PF8 rolam, PF3 encerra */
  if rc > 4 then leave
end
"TBQUERY PRODUTOS ROWNUM(N)"
"TBEND PRODUTOS"
say 'Total de linhas carregadas:' n
exit 0
