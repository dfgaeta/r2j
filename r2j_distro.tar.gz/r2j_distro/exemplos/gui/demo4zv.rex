/* REXX - demo4zv: ZVARS entre paineis, VPUT/VGET (Demo4Zvars)              */
clientes.0001 = 'MARIA SILVA'
clientes.0002 = 'JOAO SOUZA'
clientes.0003 = 'ANA PEREIRA'
address gui
do forever
  "DISPLAY PANEL(PANL010)"                  /* menu: PF3 consulta, PF12 sai */
  if zpfkey = 'PF12' then do; say 'Programa encerrado a partir do menu (PF12).'; leave; end
  codigo = strip(zclicod)
  if codigo = '' then do; say 'Nenhum codigo informado. Encerrando.'; leave; end
  if symbol('clientes.codigo') <> 'VAR' then do
    zmsg = 'CLIENTE' codigo 'NAO ENCONTRADO - TENTE NOVAMENTE'
    iterate
  end
  zmsg = ''
  zclinome = clientes.codigo
  "DISPLAY PANEL(PANL011)"                  /* )INIT VGET(&OBS) */
  if zpfkey = 'PF12' then do; say 'Programa encerrado a partir do detalhe (PF12).'; leave; end
end
"VGET (OBS) SHARED"                          /* gravado pelo VPUT(&OBS) do )PROC */
say 'Ultimo codigo consultado :' zclicod
say 'Observacao (via VPUT/VGET):' obs
exit 0
