/* REXX - guiaid: ZAID (ultima AID) e ZCSRNAME/ZCSRPOS/ZCSRROW (cursor na AID) */
/* AIDs: ENTER PF1-PF12 (Shift = PF13-24) CLEAR (Ctrl+Del / Shift+Esc) ESC     */
/*       PAUSE PGUP PGDN.  ESC = PF3 (RC 8); PGUP/PGDN rolam o )MODEL          */
address gui
"TITLE ZAID / ZCSRNAME"
say '--- DISPLAY PANL001  (ESC/PF3 encerra)'
do forever
  "DISPLAY PANEL(PANL001)"
  trc = rc
  call mostra trc
  if trc > 4 then leave
end
say '--- TBDISPL GUIAID  (coluna S do )MODEL -> ZCSRROW = linha da tabela)'
"TBCREATE PRODUTOS NAMES(COD DESC QTDE STAT) NOWRITE REPLACE"
do i = 1 to 40
  cod = i; desc = 'PRODUTO' i; qtde = i * 3; stat = 'OK'
  "TBADD PRODUTOS"
end
"TBTOP PRODUTOS"
msgaid = 'Use TAB/setas, PF1-PF12, PgUp/PgDn, Pause, Ctrl+Del (CLEAR), ESC'
do forever
  "TBDISPL PRODUTOS PANEL(GUIAID)"
  trc = rc
  call mostra trc
  msgaid = 'ZAID='zaid' ZCSRNAME='zcsrname' ZCSRPOS='zcsrpos' ZCSRROW='zcsrrow
  do while ztdsels > 0                       /* linhas com S alterado */
    say '    selecionada: linha' ztdcrp 'cod' cod 's='s
    if ztdsels = 1 then leave
    "TBDISPL PRODUTOS"
  end
  if trc > 4 then leave
end
"TBEND PRODUTOS"
exit 0

mostra:
  say left('RC='arg(1), 5) left('ZAID='zaid, 11) left('ZPFKEY='zpfkey, 13),
      'ZCSRNAME='zcsrname 'ZCSRPOS='zcsrpos 'ZCSRROW='zcsrrow
  return
