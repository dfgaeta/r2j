/* REXX - guiattr: ADDRESS GUI - TYPE/COLOR/HILITE/CAPS/PAD/JUST/INTENS e     */
/* as extensoes de )INIT/)PROC (VER NUM/LIST/RANGE/PICT, TRANS, LENGTH,      */
/* literal com &var, IF com AND/ELSE em bloco, .ATTR, .RESP)                  */
parse arg tema .
address gui
if tema <> '' then "SET THEME" tema
"TITLE Exemplo de atributos"
uf.1 = 'SP Sao Paulo'; uf.2 = 'RJ Rio de Janeiro'; uf.3 = 'MG Minas Gerais'
uf.4 = 'PR Parana';    uf.0 = 4
nome = ''; apelido = 'Dan'; obs = ''; qtde = 1; senha = ''; uf = 'SP'
cep = ''; t = ''; nota = ''; status = ''
do forever
  "DISPLAY PANEL(GUIATTR)"
  if rc > 4 then leave
  say 'ENTER ->' resumo '|' status
end
say 'Fim: RC='rc 'ZPFKEY='zpfkey
say 'NOME='nome 'APELIDO='apelido 'OBS='obs 'QTDE='qtde 'UF='uf
say 'CEP='cep 'T='t 'NOTA='nota 'TIPOX='tipox 'SLEN='slen
exit 0
