/* REXX */
say 'WHO =' who ' arg =' arg(1) ' cfg file vars ok'
say 'square from ./lib (path in cfg):' square(12)
address jcall 'sq 7 x'
say 'jcall of a generated REXX class: rc='rc 'result='result
