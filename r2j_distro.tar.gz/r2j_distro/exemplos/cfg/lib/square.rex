/* REXX */
parse arg a b
say "  square called with" a b
return a*a
