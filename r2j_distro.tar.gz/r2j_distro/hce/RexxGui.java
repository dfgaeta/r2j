import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.text.*;

/**
 * ADDRESS GUI - external dynamic Host Command Environment of r2j (extends r2j, overrides hce()).
 *
 * Displays the same ISPF .panel files used by ADDRESS ISPEXEC, but as a Swing form:
 *   )PANEL )ATTR )BODY [WINDOW(w,h)] [CMD(f)] )MODEL )INIT )PROC )END
 *   attributes TYPE(TEXT|INPUT|OUTPUT|NUM|PS|PIN|CHAR|CB) COLOR() INTENS(HIGH|LOW|NON)
 *              HILITE(USCORE|REVVID|BLINK) CAPS(ON|OFF) PAD(c) JUST(LEFT|RIGHT|ASIS)
 *   panel fields <- REXX variables before the display (and )INIT), screen -> REXX variables after.
 *
 * rexx.cfg:
 *   [hce]   hce.gui = RexxGui
 *   [jcall] source  = <directory of RexxGui.java>     (compiled on the first call)  or classpath
 *   [gui]   theme = light|dark   font = Monospaced   size = 14   buttons = yes   title = text
 *           snapshot = dir      (PNG of every display, for documentation / tests)
 *
 * After every DISPLAY / TBDISPL (and during )PROC as &ZAID ...):
 *   ZAID     last AID: ENTER PF1..PF12 (PF13..PF24 = Shift) CLEAR (Ctrl+Del, Shift+Esc) ESC PAUSE PGUP PGDN
 *   ZCSRNAME field with the cursor at the moment of the AID ('' when none)
 *   ZCSRPOS  cursor position in that field (1-based)   ZCSRROW  )MODEL data row of the field (0 = body)
 *   ESC acts as PF3 (RC 8), PGUP/PGDN as PF7/PF8 (scroll when there is a )MODEL), CLEAR/PAUSE return RC 0
 *
 * Services (same syntax and return codes as ISPEXEC):
 *   DISPLAY [PANEL(p)] [MSG(id)] [CURSOR(field)]     0 ENTER/PFk   8 PF3/PF12/END (window closed)
 *   TBDISPL table [PANEL(p)] [MSG(id)] [CURSOR(f)]   )MODEL rows from an ISPEXEC table, ZTDSELS ...
 *   ADDPOP / REMPOP [ALL]                            the next DISPLAY opens in a dialog window
 *   TITLE text    CLOSE                              window title / closes every window
 *   SET THEME dark|light   SET SIZE n   SET FONT name   SET BUTTONS yes|no   (overrides [gui])
 *   any other service (LIBDEF SETMSG VGET VPUT CONTROL TB* PQUERY ...) is executed by ISPEXEC,
 *   so LIBDEF ISPPLIB/ISPMLIB, the SHARED pool, SETMSG and the tables are common to both.
 *
 * )INIT / )PROC statements (superset of the r2j ISPEXEC dialog manager):
 *   &V = 'lit &X' | &X | word | TRUNC(&X,n|'c') | TRANS(&X a,b c,d *,'?') | UPPER(&X) | LENGTH(&X)
 *   IF (&V = a,b,c)  ops = EQ NE <> != NOT= > < >= <= GT LT GE LE  AND OR   body indented / ELSE
 *   VER (&V,NB,NUM|ENUM|ALPHA|ALPHAB|HEX|NAME|LIST,a,b|RANGE,lo,hi|LEN,op,n|PICT,'99A'[,MSG=id])
 *   VPUT (A B) [SHARED|PROFILE]   VGET (A B) [..]   .CURSOR = F   .MSG = id   .RESP = END|ENTER
 *   .ATTR(F) = 'COLOR(RED) HILITE(REVVID) INTENS(HIGH)'   EXIT   REFRESH (ignored)
 */
public class RexxGui extends r2j {

    // ------------------------------------------------------------------ state (one per RexxEnv)
    JFrame frame;
    final List<JDialog> dialogs = new ArrayList<>();
    int popups;
    String title, lastPanel, carryMsg;
    String tdTable, tdPanel;
    final List<Object[]> tdPending = new ArrayList<>();
    int snapSeq;
    View active;

    @Override
    public int hce(String host, String command) throws Exception {
        try {
            return service(command);
        } catch (RuntimeException e) {
            if (System.getProperty("r2j.gui.trace") != null) e.printStackTrace(env.err);
            return err(20, command.trim().split("\\s+")[0].toUpperCase() + ": " + e);
        }
    }

    int service(String command) throws Exception {
        Cmd c = Cmd.parse(command);
        switch (c.verb) {
            case "DISPLAY":  return display(c.kw("PANEL"), c.kw("MSG"), c.kw("CURSOR"), null);
            case "TBDISPL":  return tbdispl(c);
            case "ADDPOP":   popups++; return 0;
            case "REMPOP":
                popups = c.has("ALL") ? 0 : Math.max(0, popups - 1);
                onEdt(() -> { while (dialogs.size() > popups) dialogs.remove(dialogs.size() - 1).dispose(); });
                return 0;
            case "SET": {                                   // SET THEME dark | SIZE 16 | BUTTONS no | FONT name
                if (c.pos.isEmpty()) return err(20, "SET option value");
                String v = c.pos.size() > 1 ? String.join(" ", c.pos.subList(1, c.pos.size())) : "";
                opts.put(c.pos.get(0).toLowerCase(), v);
                return 0;
            }
            case "TITLE":
                title = command.trim().length() > 5 ? command.trim().substring(5).trim() : "";
                onEdt(() -> { if (frame != null) frame.setTitle(frameTitle(lastPanel)); });
                return 0;
            case "CLOSE": case "TERM":
                onEdt(() -> {
                    for (JDialog d : dialogs) d.dispose();
                    dialogs.clear();
                    if (frame != null) frame.dispose();
                    frame = null;
                });
                popups = 0;
                return 0;
            default:
                return r2j.IspfApi.ispexec(prog, command);   // LIBDEF SETMSG VGET VPUT CONTROL TB* ...
        }
    }

    // ------------------------------------------------------------------ DISPLAY / TBDISPL
    int display(String panel, String msg, String cursor, List<Map<String, String>> model) throws Exception {
        String pn = panel != null ? panel : lastPanel;
        if (pn == null) return err(20, "DISPLAY: no panel name");
        if (GraphicsEnvironment.isHeadless()) return err(20, "DISPLAY " + pn.toUpperCase() + ": no graphical display (DISPLAY not set / headless)");
        Path f = r2j.IspfApi.findPanel(prog, pn);
        if (f == null) return err(12, "panel " + pn + " not found in ISPPLIB " + r2j.IspfApi.lib(prog, "ISPPLIB"));
        IspfPanel.ZVarPool zv = r2j.IspfApi.zvars(prog);
        IspfPanel p;
        try { p = IspfPanel.IspfPanelParser.parse(f, zv); }
        catch (RuntimeException e) { return err(20, "panel " + pn + ": " + e.getMessage()); }
        lastPanel = pn;
        toPanel(p);
        if (model != null) p.setModelData(model);
        Proc init = new Proc(p, zv, prog);
        init.run(p.initLines);
        String m = msg;
        if (m == null) m = r2j.IspfApi.takeSetMsg(prog);
        String text = null; boolean alarm = false;
        if (m != null) { String[] mm = r2j.IspfApi.message(prog, m); text = join(mm); alarm = "YES".equals(mm[2]); }
        else if (init.msg != null) { String[] mm = r2j.IspfApi.message(prog, init.msg); text = join(mm); alarm = "YES".equals(mm[2]); }
        else if (carryMsg != null) text = carryMsg;
        carryMsg = null;
        String csr = cursor != null ? cursor.toUpperCase() : init.cursor;
        final String ftext = text; final boolean falarm = alarm;
        CompletableFuture<String> done = new CompletableFuture<>();
        boolean popup = popups > 0;
        onEdt(() -> {
            View v = new View(this, p, zv, popup, done);
            active = v;
            v.show(ftext, falarm, csr);
        });
        String key;
        try { key = done.get(); }
        catch (ExecutionException e) { return err(20, "DISPLAY " + pn + ": " + e.getCause()); }
        finally { active = null; }
        fromPanel(p, zv);
        return "PF3".equals(key) || "PF12".equals(key) || "PF15".equals(key) || "PF24".equals(key) ? 8 : 0;
    }

    int tbdispl(Cmd c) throws Exception {
        String tn = c.first();
        if (tn == null || !r2j.IspfApi.tbIsOpen(prog, tn)) return err(12, "TBDISPL: table " + tn + " not open");
        tn = tn.toUpperCase();
        String panel = c.kw("PANEL");
        if (panel == null && tn.equals(tdTable) && !tdPending.isEmpty()) return nextPending(tn);
        String pn = panel != null ? panel : tdPanel;
        if (pn == null) return err(20, "TBDISPL: no panel");
        tdTable = tn; tdPanel = pn;
        tdPending.clear();
        List<Map<String, String>> rows = r2j.IspfApi.tbRows(prog, tn);
        List<Map<String, String>> disp = new ArrayList<>(), snap = new ArrayList<>();
        for (Map<String, String> r : rows) { disp.add(new LinkedHashMap<>(r)); snap.add(new LinkedHashMap<>(r)); }
        int crp = r2j.IspfApi.tbCrp(prog, tn);
        String top = prog.rawSym("ZTDTOP");
        int start = crp > 0 ? crp : 1;
        if (top != null && panel == null) try { start = Math.max(1, Integer.parseInt(top.trim())); } catch (NumberFormatException ignore) { }
        tdStart = start;
        int rc = display(pn, c.kw("MSG"), c.kw("CURSOR"), disp);
        if (rc >= 12) return rc;
        prog.setSym("ZTDTOP", String.valueOf(tdTop + 1));
        prog.setSym("ZTDROWS", String.valueOf(rows.size()));
        prog.setSym("ZTDVROWS", String.valueOf(Math.min(tdVis, rows.size())));
        for (int i = 0; i < disp.size(); i++) if (!disp.get(i).equals(snap.get(i))) tdPending.add(new Object[]{ i, disp.get(i) });
        if (tdPending.isEmpty()) { prog.setSym("ZTDSELS", "0"); return rc; }
        int r2 = nextPending(tn);
        return rc == 8 ? 8 : r2;
    }
    int tdStart = 1, tdTop, tdVis;
    String aid = "", csrName = "", csrRow = "0";
    int csrPos;

    @SuppressWarnings("unchecked")
    int nextPending(String tn) {
        Object[] e = tdPending.remove(0);
        int idx = (Integer) e[0];
        Map<String, String> row = (Map<String, String>) e[1];
        r2j.IspfApi.tbSetCrp(prog, tn, idx + 1, true);
        for (Map.Entry<String, String> x : row.entrySet())
            if (!r2j.IspfApi.tbInternalKey(x.getKey())) prog.setSym(x.getKey(), x.getValue());
        prog.setSym("ZTDSELS", String.valueOf(tdPending.size() + 1));
        prog.setSym("ZTDCRP", String.valueOf(idx + 1));
        return tdPending.isEmpty() ? 0 : 4;
    }

    int err(int rc, String m) {
        prog.setSym("ZERRSM", "GUI ERROR");
        prog.setSym("ZERRLM", m);
        env.err.println("r2j: ADDRESS GUI: " + m);
        return rc;
    }

    static String join(String[] m) { return m[1] == null || m[1].isEmpty() ? m[0] : m[0] + " - " + m[1]; }

    // ------------------------------------------------------------------ variables <-> panel
    void toPanel(IspfPanel p) {
        for (String n : p.getAllFieldNames()) {
            String v = prog.rawSym(n);
            if (v != null) try { p.setField(n, v); } catch (RuntimeException ignore) { }
        }
        if (p.hasField("ZCMD") && prog.rawSym("ZCMD") == null) p.setField("ZCMD", "");
        for (String n : p.getAllFieldNames()) {                   // TYPE(CB): stem <field>.n = "value label"
            if (!p.isComboField(n)) continue;
            String cnt = prog.rawSym(n + ".0");
            int k;
            try { k = cnt == null ? -1 : Integer.parseInt(cnt.trim()); } catch (NumberFormatException e) { k = -1; }
            if (k < 0) continue;
            List<Map<String, String>> opts = new ArrayList<>();
            for (int i = 1; i <= k; i++) {
                String e = prog.rawSym(n + "." + i);
                if (e == null) continue;
                String[] w = e.trim().split("\\s+", 2);
                Map<String, String> m = new LinkedHashMap<>();
                m.put("VALUE", w[0]);
                m.put("LABEL", w.length > 1 ? w[1] : w[0]);
                opts.add(m);
            }
            p.setComboData(n, opts);
        }
    }

    void fromPanel(IspfPanel p, IspfPanel.ZVarPool zv) {
        for (String n : p.getAllFieldNames()) try { prog.setSym(n, p.getField(n)); } catch (RuntimeException ignore) { }
        prog.setSym("ZPFKEY", zv.get("ZPFKEY"));
        prog.setSym("ZAID", aid);                       // ENTER PF1..PF24 CLEAR ESC PAUSE PGUP PGDN
        prog.setSym("ZCSRNAME", csrName);               // field with the cursor at the AID ('' = none)
        prog.setSym("ZCSRPOS", String.valueOf(csrPos)); // position of the cursor in that field (1-based)
        prog.setSym("ZCSRROW", csrRow);                 // )MODEL / TBDISPL: data row of the field (0 = body)
        if (!p.hasField("ZCMD")) prog.setSym("ZCMD", zv.get("ZCMD"));
    }

    final Map<String, String> opts = new HashMap<>();
    String cfg(String k, String d) { String o = opts.get(k); return o != null ? o : env.cfg("GUI", k, d); }

    String frameTitle(String panel) {
        String t = title != null ? title : cfg("title", "r2j");
        return panel == null ? t : t + " - " + panel.toUpperCase();
    }

    static void onEdt(Runnable r) throws Exception {
        if (SwingUtilities.isEventDispatchThread()) { r.run(); return; }
        try { SwingUtilities.invokeAndWait(r); }
        catch (java.lang.reflect.InvocationTargetException e) {
            Throwable t = e.getCause();
            if (t instanceof RuntimeException x) throw x;
            if (t instanceof Error x) throw x;
            throw new RuntimeException(t);
        }
    }

    // ==================================================================================== theme
    static final class Theme {
        final boolean dark;
        final Color bg, inBg, inLine, status, statusErr, dim;
        final Font plain, bold;
        final int cw, ch, asc;
        Theme(String name, String font, int size) {
            dark = name.equalsIgnoreCase("dark") || name.equals("3270");
            bg = dark ? Color.BLACK : new Color(0xF4, 0xF3, 0xEE);
            inBg = dark ? new Color(0x10, 0x10, 0x10) : Color.WHITE;
            inLine = dark ? new Color(0x50, 0x50, 0x50) : new Color(0xB8, 0xB8, 0xB0);
            status = dark ? new Color(0x40, 0xE0, 0xD0) : new Color(0x1F, 0x4E, 0x79);
            statusErr = dark ? new Color(0xFF, 0x60, 0x60) : new Color(0xB0, 0x00, 0x00);
            dim = dark ? new Color(0x60, 0x60, 0x60) : new Color(0xA0, 0xA0, 0xA0);
            plain = new Font(font, Font.PLAIN, size);
            bold = new Font(font, Font.BOLD, size);
            BufferedImage im = new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = im.createGraphics();
            FontMetrics fm = g.getFontMetrics(plain);
            cw = fm.charWidth('M');
            ch = fm.getHeight() + 4;
            asc = fm.getAscent() + 2;
            g.dispose();
        }
        Color fg(IspfPanel.IspfAttribute a) {
            IspfPanel.IspfAttribute.Color c = a.color;
            if (dark) return switch (c) {
                case BLUE -> new Color(0x60, 0x90, 0xFF); case RED -> new Color(0xFF, 0x50, 0x50);
                case PINK -> new Color(0xFF, 0x80, 0xE0); case GREEN -> new Color(0x50, 0xE6, 0x50);
                case TURQ -> new Color(0x40, 0xE0, 0xD0); case YELLOW -> new Color(0xFF, 0xFF, 0x40);
                default -> new Color(0xE6, 0xE6, 0xE6);
            };
            return switch (c) {
                case BLUE -> new Color(0x00, 0x30, 0xB0); case RED -> new Color(0xB0, 0x00, 0x00);
                case PINK -> new Color(0xA0, 0x00, 0x90); case GREEN -> new Color(0x00, 0x70, 0x20);
                case TURQ -> new Color(0x00, 0x70, 0x80); case YELLOW -> new Color(0x8A, 0x5A, 0x00);
                default -> new Color(0x20, 0x20, 0x20);
            };
        }
        Font font(IspfPanel.IspfAttribute a) { return a.intens == IspfPanel.IspfAttribute.Intens.HIGH ? bold : plain; }
    }

    // ==================================================================================== view
    /** one DISPLAY: the panel painted on a grid (rows x cols), input fields as Swing components */
    static final class View {
        final RexxGui g;
        final IspfPanel pn;
        final IspfPanel.ZVarPool zv;
        final CompletableFuture<String> done;
        final Theme th;
        final boolean popup;
        Window win;
        Grid grid;
        JLabel status;
        final List<Object[]> live = new ArrayList<>();      // {IspfLiveField, JComponent}
        List<List<IspfPanel.RenderToken>> canvas;
        boolean activeView = true, blinkOff;
        javax.swing.Timer blink;

        View(RexxGui g, IspfPanel pn, IspfPanel.ZVarPool zv, boolean popup, CompletableFuture<String> done) {
            this.g = g; this.pn = pn; this.zv = zv; this.popup = popup; this.done = done;
            this.th = new Theme(g.cfg("theme", "light"), g.cfg("font", "Monospaced"), parseInt(g.cfg("size", "14"), 14));
        }

        static int parseInt(String s, int d) { try { return Integer.parseInt(s.trim()); } catch (RuntimeException e) { return d; } }

        void show(String msg, boolean alarm, String cursor) {
            if (g.tdStart > 1) pn.scrollModel(g.tdStart - 1);
            g.tdStart = 1;
            JPanel root = new JPanel(new BorderLayout());
            root.setBackground(th.bg);
            grid = new Grid(this);
            root.add(grid, BorderLayout.CENTER);
            JPanel south = new JPanel(new BorderLayout());
            south.setBackground(th.dark ? new Color(0x18, 0x18, 0x18) : new Color(0xE4, 0xE2, 0xDA));
            status = new JLabel(" ");
            status.setFont(th.plain.deriveFont(Font.BOLD));
            status.setBorder(BorderFactory.createEmptyBorder(3, 6, 3, 6));
            south.add(status, BorderLayout.CENTER);
            if (!"no".equalsIgnoreCase(g.cfg("buttons", "yes").trim())) south.add(buttons(), BorderLayout.EAST);
            root.add(south, BorderLayout.SOUTH);
            bindKeys(root);
            MenuSelectionManager.defaultManager().clearSelectedPath();   // no popup (combo list) left open
            KeyboardFocusManager.getCurrentKeyboardFocusManager().clearGlobalFocusOwner();

            if (popup) {
                while (g.dialogs.size() > g.popups) g.dialogs.remove(g.dialogs.size() - 1).dispose();
                JDialog d;
                if (g.dialogs.size() == g.popups) d = g.dialogs.get(g.popups - 1);
                else {
                    Window owner = g.dialogs.isEmpty() ? g.frame : g.dialogs.get(g.dialogs.size() - 1);
                    d = new JDialog(owner, Dialog.ModalityType.MODELESS);
                    d.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
                    g.dialogs.add(d);
                }
                String wt = zv.get("ZWINTTL");
                if (wt == null || wt.isBlank()) wt = g.prog.rawSym("ZWINTTL");
                d.setTitle(wt == null || wt.isBlank() ? pn.name : wt);
                for (WindowListener l : d.getWindowListeners()) d.removeWindowListener(l);
                d.addWindowListener(closer());
                d.setContentPane(root);
                d.pack();
                Window owner = d.getOwner();
                if (owner != null && owner.isShowing()) d.setLocationRelativeTo(owner);
                d.setVisible(true);
                win = d;
                if (g.frame != null) g.frame.setEnabled(false);
            } else {
                for (JDialog d : g.dialogs) d.dispose();
                g.dialogs.clear();
                if (g.frame == null) {
                    g.frame = new JFrame();
                    g.frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
                    g.frame.setLocationByPlatform(true);
                }
                for (WindowListener l : g.frame.getWindowListeners()) g.frame.removeWindowListener(l);
                g.frame.addWindowListener(closer());
                g.frame.setEnabled(true);
                g.frame.setTitle(g.frameTitle(pn.name));
                g.frame.setContentPane(root);
                g.frame.pack();
                g.frame.setResizable(false);
                g.frame.setVisible(true);
                win = g.frame;
            }
            setMessage(msg, alarm);
            setCursor(cursor);
            win.toFront();
            blink = new javax.swing.Timer(500, e -> { blinkOff = !blinkOff; grid.repaint(); });
            if (hasBlink()) blink.start();
            snapshot();
        }

        WindowAdapter closer() {
            return new WindowAdapter() {
                @Override public void windowClosing(WindowEvent e) { if (activeView) key("PF3"); }   // ZAID = PF3
            };
        }

        JPanel buttons() {
            JPanel b = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 2));
            b.setOpaque(false);
            List<String[]> ks = new ArrayList<>();
            ks.add(new String[]{ "ENTER", "Enter" });
            if (pn.visibleModelRows() > 0) { ks.add(new String[]{ "PF7", "F7 \u25b2" }); ks.add(new String[]{ "PF8", "F8 \u25bc" }); }
            ks.add(new String[]{ "PF3", "F3 Fim" });
            ks.add(new String[]{ "PF12", "F12 Cancelar" });
            for (String[] k : ks) {
                JButton bt = new JButton(k[1]);
                bt.setFocusable(false);
                bt.setMargin(new Insets(1, 8, 1, 8));
                bt.addActionListener(e -> key(k[0]));
                b.add(bt);
            }
            return b;
        }

        void bindKeys(JComponent root) {
            InputMap im = root.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
            ActionMap am = root.getActionMap();
            bind(im, am, KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "ENTER");
            bind(im, am, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "ESC");
            bind(im, am, KeyStroke.getKeyStroke(KeyEvent.VK_PAGE_UP, 0), "PGUP");
            bind(im, am, KeyStroke.getKeyStroke(KeyEvent.VK_PAGE_DOWN, 0), "PGDN");
            bind(im, am, KeyStroke.getKeyStroke(KeyEvent.VK_PAUSE, 0), "PAUSE");
            bind(im, am, KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, InputEvent.CTRL_DOWN_MASK), "CLEAR");
            bind(im, am, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, InputEvent.SHIFT_DOWN_MASK), "CLEAR");
            for (int i = 1; i <= 12; i++) {
                bind(im, am, KeyStroke.getKeyStroke(KeyEvent.VK_F1 + i - 1, 0), "PF" + i);
                bind(im, am, KeyStroke.getKeyStroke(KeyEvent.VK_F1 + i - 1, InputEvent.SHIFT_DOWN_MASK), "PF" + (i + 12));
            }
        }

        void bind(InputMap im, ActionMap am, KeyStroke ks, String k) {
            im.put(ks, k);
            am.put(k, new AbstractAction() { @Override public void actionPerformed(ActionEvent e) { key(k); } });
        }

        boolean hasBlink() {
            for (List<IspfPanel.RenderToken> l : canvas) for (IspfPanel.RenderToken t : l)
                if (attrOf(t).hilite == IspfPanel.IspfAttribute.Hilite.BLINK) return true;
            return false;
        }

        static IspfPanel.IspfAttribute attrOf(IspfPanel.RenderToken t) {
            return t instanceof IspfPanel.RenderToken.Text x ? x.attr : ((IspfPanel.RenderToken.Field) t).field.attr;
        }

        // ------------------------------------------------------------- keys
        void key(String aid) {
            if (!activeView) return;
            // AID -> function: ESC = PF3, PGUP/PGDN = PF7/PF8 (scroll of )MODEL), CLEAR / PAUSE return as is
            String k = switch (aid) { case "ESC" -> "PF3"; case "PGUP" -> "PF7"; case "PGDN" -> "PF8"; default -> aid; };
            try {
                cursorAt(aid);
                if (!aid.equals("CLEAR")) commit();                // CLEAR does not send the screen data (3270)
                if (k.equals("PF7") || k.equals("PF8")) {
                    if (pn.visibleModelRows() > 0) {
                        int n = pn.visibleModelRows();
                        pn.scrollModel(k.equals("PF7") ? -n : n);
                        String f = focusedName();
                        grid.rebuild();
                        setCursor(f);
                        return;
                    }
                }
                zv.put("ZPFKEY", k.equals("ENTER") ? "PF00" : k);   // as ISPEXEC: PF00 PF3 PF12 ... (CLEAR, PAUSE)
                String ret = k;
                if (k.equals("ENTER")) {
                    Proc pr = new Proc(pn, zv, g.prog);
                    pr.run(pn.procLines);
                    String text = null; boolean alarm = false;
                    if (pr.msg != null) { String[] mm = r2j.IspfApi.message(g.prog, pr.msg); text = join(mm); alarm = "YES".equals(mm[2]) || !pr.valid; }
                    if (!pr.valid) {
                        grid.reload();
                        setMessage(text, true);
                        setCursor(pr.cursor);
                        Toolkit.getDefaultToolkit().beep();
                        return;
                    }
                    if ("END".equals(pr.resp)) ret = "PF3";
                    g.carryMsg = text;
                }
                finish(ret);
            } catch (RuntimeException e) {
                finishError(e);
            }
        }

        void finish(String k) {
            activeView = false;
            if (blink != null) blink.stop();
            g.tdTop = pn.getModelScrollOffset();
            g.tdVis = pn.visibleModelRows();
            win.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            for (Object[] o : live) {
                if (o[1] instanceof JComboBox<?> cb && cb.isPopupVisible()) cb.hidePopup();
                ((JComponent) o[1]).setEnabled(false);
            }
            if (popup && g.frame != null) g.frame.setEnabled(true);
            done.complete(k);
        }

        void finishError(Throwable t) {
            activeView = false;
            if (blink != null) blink.stop();
            done.completeExceptionally(t);
        }

        /** screen -> panel fields */
        void commit() {
            for (Object[] o : live) {
                IspfPanel.IspfLiveField f = (IspfPanel.IspfLiveField) o[0];
                JComponent c = (JComponent) o[1];
                String nv = null;
                if (c instanceof JComboBox<?> cb) { Object s = cb.getSelectedItem(); if (s instanceof Opt op) nv = op.value; }
                else if (c instanceof JPasswordField pw) nv = new String(pw.getPassword());
                else if (c instanceof JTextField tf) nv = rtrimPad(tf.getText(), f.attr.pad);
                String ov = f.getValue();
                if (nv != null && !nv.equals(ov == null ? "" : ov)) f.setValue(nv);   // only modified fields (MDT)
            }
        }

        static String rtrimPad(String s, char pad) {
            if (pad == ' ') return s;
            int e = s.length();
            while (e > 0 && s.charAt(e - 1) == pad) e--;
            return s.substring(0, e);
        }

        /** ZAID / ZCSRNAME / ZCSRPOS / ZCSRROW at the moment of the AID (also visible to )PROC as &ZAID ...) */
        void cursorAt(String aid) {
            String name = "", row = "0";
            int pos = 0;
            Component fo = KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
            for (Object[] o : live) {
                JComponent c = (JComponent) o[1];
                if (c != fo && !(fo != null && SwingUtilities.isDescendingFrom(fo, c))) continue;
                name = ((IspfPanel.IspfLiveField) o[0]).name;
                int h = name.indexOf('#');                          // )MODEL field: NAME#index of the data row
                if (h >= 0) { row = String.valueOf(Integer.parseInt(name.substring(h + 1)) + 1); name = name.substring(0, h); }
                if (c instanceof JTextField tf) {
                    int sel = tf.getSelectionStart() != tf.getSelectionEnd() ? tf.getSelectionStart() : tf.getCaretPosition();
                    pos = sel + 1;
                } else pos = 1;
                break;
            }
            g.aid = aid; g.csrName = name.toUpperCase(); g.csrPos = pos; g.csrRow = row;
            zv.put("ZAID", aid);
            zv.put("ZCSRNAME", g.csrName);
            zv.put("ZCSRPOS", String.valueOf(pos));
            zv.put("ZCSRROW", row);
        }

        String focusedName() {
            Component fo = KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
            for (Object[] o : live) if (o[1] == fo) return ((IspfPanel.IspfLiveField) o[0]).name;
            return null;
        }

        void setMessage(String text, boolean alarm) {
            status.setText(text == null || text.isEmpty() ? " " : text);
            status.setForeground(alarm ? th.statusErr : th.status);
            status.setToolTipText(text == null || text.isEmpty() ? null : text);
            if (alarm && text != null && !text.isEmpty()) Toolkit.getDefaultToolkit().beep();
        }

        /** focus the field (name, or model field NAME -> first visible row); default: first input */
        void setCursor(String name) {
            JComponent target = null;
            if (name != null) {
                String u = name.toUpperCase();
                for (Object[] o : live) {
                    String n = ((IspfPanel.IspfLiveField) o[0]).name.toUpperCase();
                    if (n.equals(u) || n.startsWith(u + "#")) { target = (JComponent) o[1]; break; }
                }
            }
            if (target == null && !live.isEmpty()) target = (JComponent) live.get(0)[1];
            if (target == null) { win.toFront(); grid.setFocusable(true); grid.requestFocus(); }
            if (target != null) {
                JComponent t = target;
                if (!win.isFocused()) { win.toFront(); t.requestFocus(); }
                t.requestFocusInWindow();
                SwingUtilities.invokeLater(() -> { if (!t.isFocusOwner()) t.requestFocus(); });
                if (t instanceof JTextField tf) SwingUtilities.invokeLater(tf::selectAll);   // typing replaces (ISPF overtype)
            }
        }

        void snapshot() {
            String dir = g.cfg("snapshot", null);
            if (dir == null || dir.isBlank()) return;
            int seq = ++g.snapSeq;
            SwingUtilities.invokeLater(() -> SwingUtilities.invokeLater(() -> {
                try {
                    Container c = win instanceof JFrame f ? f.getContentPane() : ((JDialog) win).getContentPane();
                    BufferedImage im = new BufferedImage(c.getWidth(), c.getHeight(), BufferedImage.TYPE_INT_RGB);
                    Graphics2D g2 = im.createGraphics();
                    c.paintAll(g2);
                    g2.dispose();
                    Path d = Paths.get(dir.trim());
                    Files.createDirectories(d);
                    ImageIO.write(im, "png", d.resolve(String.format("%03d_%s.png", seq, pn.name)).toFile());
                } catch (Exception ignore) { }
            }));
        }
    }

    /** combobox option */
    static final class Opt {
        final String value, label;
        Opt(String v, String l) { value = v; label = l; }
        @Override public String toString() { return label.equals(value) ? value : value + " - " + label; }
    }

    // ==================================================================================== grid
    /** paints texts / output fields on the character grid and holds the input components */
    static final class Grid extends JPanel {
        final View v;
        final Theme th;

        Grid(View v) {
            super(null);
            this.v = v;
            this.th = v.th;
            setBackground(th.bg);
            setPreferredSize(new Dimension(v.pn.cols() * th.cw + 16, v.pn.rows() * th.ch + 12));
            setFocusCycleRoot(true);
            setFocusTraversalPolicy(new ContainerOrderFocusTraversalPolicy() {
                @Override protected boolean accept(Component c) { return c != Grid.this && c.isEnabled() && c.isFocusable() && c.isVisible(); }
            });
            addMouseWheelListener(e -> {
                if (v.pn.visibleModelRows() > 0) v.key(e.getWheelRotation() < 0 ? "PF7" : "PF8");
            });
            rebuild();
        }

        int x(int col) { return 8 + col * th.cw; }
        int y(int row) { return 6 + row * th.ch; }

        /** (re)creates the input components from the current canvas (after model scroll) */
        void rebuild() {
            removeAll();
            v.live.clear();
            v.canvas = v.pn.buildFullCanvas();
            for (int r = 0; r < v.canvas.size(); r++) {
                int col = 0;
                for (IspfPanel.RenderToken t : v.canvas.get(r)) {
                    if (t instanceof IspfPanel.RenderToken.Field ft && !ft.field.isProtected()) {
                        JComponent c = component(ft.field);
                        int w = ft.field.attr.isCombo() ? Math.max(ft.field.length * th.cw + 26, 60) : ft.field.length * th.cw + 3;
                        c.setBounds(x(col), y(r), w, th.ch - 1);
                        add(c);
                        v.live.add(new Object[]{ ft.field, c });
                    }
                    col += t.length;
                }
            }
            revalidate();
            repaint();
        }

        /** panel fields -> components (after a failed VER / )PROC assignments) */
        void reload() {
            for (Object[] o : v.live) {
                IspfPanel.IspfLiveField f = (IspfPanel.IspfLiveField) o[0];
                JComponent c = (JComponent) o[1];
                if (c instanceof JComboBox<?> cb) select(cb, f.getValue());
                else if (c instanceof JTextField tf) { tf.setText(f.getValue()); style(tf, f.attr); }
            }
            repaint();
        }

        JComponent component(IspfPanel.IspfLiveField f) {
            IspfPanel.IspfAttribute a = f.attr;
            if (a.isCombo()) {
                JComboBox<Opt> cb = new JComboBox<>();
                String base = f.name.contains("#") ? f.name.substring(0, f.name.indexOf('#')) : f.name;
                for (Map<String, String> m : v.pn.getComboData(base)) {
                    String val = m.getOrDefault("VALUE", "");
                    cb.addItem(new Opt(val, m.getOrDefault("LABEL", val)));
                }
                select(cb, f.getValue());
                cb.setFont(th.font(a));
                cb.setForeground(th.fg(a));
                cb.setBackground(th.inBg);
                cb.getInputMap(JComponent.WHEN_FOCUSED).put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "none");
                cb.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "none");
                return cb;
            }
            JTextField tf = a.intens == IspfPanel.IspfAttribute.Intens.NON ? new JPasswordField() : new PadField(th);
            ((AbstractDocument) tf.getDocument()).setDocumentFilter(new Filter(f.length, a));
            tf.setText(f.getValue());
            tf.setMargin(new Insets(0, 0, 0, 0));
            tf.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, th.inLine));
            if (a.just == IspfPanel.IspfAttribute.Just.RIGHT) tf.setHorizontalAlignment(JTextField.RIGHT);
            style(tf, a);
            InputMap im = tf.getInputMap(JComponent.WHEN_FOCUSED);
            im.put(KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0), "r2j-up");
            im.put(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0), "r2j-down");
            tf.getActionMap().put("r2j-up", new AbstractAction() { @Override public void actionPerformed(ActionEvent e) { vertical(tf, -1); } });
            tf.getActionMap().put("r2j-down", new AbstractAction() { @Override public void actionPerformed(ActionEvent e) { vertical(tf, 1); } });
            tf.addFocusListener(new FocusAdapter() {
                @Override public void focusGained(FocusEvent e) { if (!(tf instanceof JPasswordField)) tf.selectAll(); }
            });
            return tf;
        }

        void style(JTextField tf, IspfPanel.IspfAttribute a) {
            Color fg = th.fg(a), bg = th.inBg;
            if (a.hilite == IspfPanel.IspfAttribute.Hilite.REVVID) { Color t = fg; fg = bg; bg = t; }
            tf.setFont(th.font(a));
            tf.setForeground(fg);
            tf.setBackground(bg);
            tf.setCaretColor(fg);
            tf.setDisabledTextColor(fg);
            if (tf instanceof PadField pf) { pf.attr = a; pf.uscore = a.hilite == IspfPanel.IspfAttribute.Hilite.USCORE; }
        }

        /** ARROW UP / DOWN: closest input field on the previous / next line */
        void vertical(JComponent from, int dir) {
            Rectangle r0 = from.getBounds();
            JComponent best = null;
            int bestD = Integer.MAX_VALUE;
            for (Object[] o : v.live) {
                JComponent c = (JComponent) o[1];
                Rectangle r = c.getBounds();
                if (dir < 0 ? r.y >= r0.y : r.y <= r0.y) continue;
                int d = Math.abs(r.y - r0.y) * 1000 + Math.abs(r.x - r0.x);
                if (d < bestD) { bestD = d; best = c; }
            }
            if (best != null) best.requestFocusInWindow();
        }

        static void select(JComboBox<?> cb, String value) {
            for (int i = 0; i < cb.getItemCount(); i++)
                if (((Opt) cb.getItemAt(i)).value.equals(value)) { cb.setSelectedIndex(i); return; }
            if (value != null && !value.isEmpty()) {
                @SuppressWarnings("unchecked") JComboBox<Opt> c = (JComboBox<Opt>) cb;
                c.insertItemAt(new Opt(value, value), 0);
                c.setSelectedIndex(0);
            } else if (cb.getItemCount() > 0) cb.setSelectedIndex(-1);
        }

        @Override
        protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            Graphics2D g = (Graphics2D) g0;
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            for (int r = 0; r < v.canvas.size(); r++) {
                int col = 0;
                for (IspfPanel.RenderToken t : v.canvas.get(r)) {
                    if (t instanceof IspfPanel.RenderToken.Text tx) cells(g, tx.text, col, r, tx.attr);
                    else {
                        IspfPanel.IspfLiveField f = ((IspfPanel.RenderToken.Field) t).field;
                        if (f.isProtected()) cells(g, f.displayValue(), col, r, f.attr);
                    }
                    col += t.length;
                }
            }
        }

        void cells(Graphics2D g, String s, int col, int row, IspfPanel.IspfAttribute a) {
            if (s.isEmpty() || a.intens == IspfPanel.IspfAttribute.Intens.NON) return;
            Color fg = th.fg(a);
            int x0 = x(col), y0 = y(row);
            if (a.hilite == IspfPanel.IspfAttribute.Hilite.REVVID) {
                int a0 = 0, a1 = s.length();                      // reverse video on the text, not on the blanks around it
                while (a0 < a1 && s.charAt(a0) == ' ') a0++;
                while (a1 > a0 && s.charAt(a1 - 1) == ' ') a1--;
                if (a1 > a0) {
                    g.setColor(fg);
                    g.fillRect(x0 + a0 * th.cw, y0, (a1 - a0) * th.cw, th.ch - 1);
                    fg = th.bg;
                }
            }
            if (a.hilite == IspfPanel.IspfAttribute.Hilite.BLINK && v.blinkOff) return;
            g.setFont(th.font(a));
            g.setColor(fg);
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (c != ' ') g.drawString(String.valueOf(c), x0 + i * th.cw, y0 + th.asc);
            }
            if (a.hilite == IspfPanel.IspfAttribute.Hilite.USCORE) {
                String t = s.stripTrailing();
                if (!t.isEmpty()) g.drawLine(x0, y0 + th.ch - 3, x0 + t.length() * th.cw, y0 + th.ch - 3);
            }
        }
    }

    /** input field that shows the PAD character on the free positions and HILITE(USCORE) */
    static final class PadField extends JTextField {
        final Theme th;
        IspfPanel.IspfAttribute attr;
        boolean uscore;
        PadField(Theme th) { this.th = th; }
        @Override
        protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            if (attr == null) return;
            Graphics2D g = (Graphics2D) g0;
            FontMetrics fm = g.getFontMetrics(getFont());
            int len = getText().length(), max = ((Filter) ((AbstractDocument) getDocument()).getDocumentFilter()).max;
            Insets in = getInsets();
            int cw = fm.charWidth('M'), base = in.top + (getHeight() - in.top - in.bottom - fm.getHeight()) / 2 + fm.getAscent();
            boolean right = attr.just == IspfPanel.IspfAttribute.Just.RIGHT;
            if (attr.pad != ' ') {
                g.setColor(th.dim);
                for (int i = len; i < max; i++) {
                    int cell = right ? i - len : i;
                    g.drawString(String.valueOf(attr.pad), in.left + cell * cw, base);
                }
            }
            if (uscore && len > 0) {
                g.setColor(getForeground());
                int x0 = right ? getWidth() - in.right - len * cw : in.left;
                g.drawLine(x0, base + 2, x0 + len * cw, base + 2);
            }
        }
    }

    /** LEN / CAPS(ON) / TYPE(NUM) on typing */
    static final class Filter extends DocumentFilter {
        final int max;
        final IspfPanel.IspfAttribute a;
        Filter(int max, IspfPanel.IspfAttribute a) { this.max = max; this.a = a; }
        String fix(String s) {
            if (s == null) return "";
            if (a.caps) s = s.toUpperCase();
            if (a.type == IspfPanel.IspfAttribute.Type.NUM) {
                StringBuilder b = new StringBuilder();
                for (char c : s.toCharArray()) if (Character.isDigit(c) || "+-.,".indexOf(c) >= 0) b.append(c);
                s = b.toString();
            }
            return s;
        }
        @Override public void insertString(FilterBypass fb, int off, String s, AttributeSet at) throws BadLocationException {
            replace(fb, off, 0, s, at);
        }
        @Override public void replace(FilterBypass fb, int off, int len, String s, AttributeSet at) throws BadLocationException {
            s = fix(s);
            int room = max - (fb.getDocument().getLength() - len);
            if (room <= 0 && s.length() > 0) { Toolkit.getDefaultToolkit().beep(); if (len > 0) fb.remove(off, len); return; }
            if (s.length() > room) s = s.substring(0, room);
            fb.replace(off, len, s, at);
        }
    }

    // ==================================================================================== )INIT / )PROC
    /** panel statements interpreter (compatible with the r2j ISPEXEC dialog manager, plus extensions) */
    static final class Proc {
        final IspfPanel pn;
        final IspfPanel.ZVarPool zv;
        final RexxProgram p;
        String msg, cursor, resp;
        boolean valid = true;
        boolean stop;

        Proc(IspfPanel pn, IspfPanel.ZVarPool zv) { this(pn, zv, null); }
        Proc(IspfPanel pn, IspfPanel.ZVarPool zv, RexxProgram p) { this.pn = pn; this.zv = zv; this.p = p; }

        RexxProgram prog() { return p; }

        void run(List<String> lines) {
            if (lines == null || lines.isEmpty()) return;
            List<String> ls = new ArrayList<>();
            for (String l : lines) if (!l.isBlank() && !l.strip().startsWith("*")) ls.add(l.replace('\t', ' '));
            block(ls, 0, ls.size());
        }

        static int indent(String s) { int i = 0; while (i < s.length() && s.charAt(i) == ' ') i++; return i; }

        void block(List<String> ls, int from, int to) {
            int i = from;
            while (i < to && !stop) {
                String raw = ls.get(i), st = raw.strip();
                int ind = indent(raw);
                String up = st.toUpperCase();
                if (up.startsWith("IF") && st.length() > 2 && (st.charAt(2) == '(' || st.charAt(2) == ' ') && st.indexOf('(') >= 0) {
                    int lp = st.indexOf('('), rp = close(st, lp);
                    String cond = st.substring(lp + 1, rp < 0 ? st.length() : rp);
                    String inline = rp < 0 ? "" : st.substring(rp + 1).trim();
                    int j = i + 1;
                    while (j < to && indent(ls.get(j)) > ind) j++;
                    int bodyFrom = i + 1, bodyTo = j;
                    if (inline.isEmpty() && bodyTo == bodyFrom && j < to && !ls.get(j).strip().equalsIgnoreCase("ELSE")) { bodyTo = j + 1; j++; }
                    int eFrom = -1, eTo = -1;
                    if (j < to && ls.get(j).strip().toUpperCase().startsWith("ELSE")) {
                        String er = ls.get(j).strip().substring(4).trim();
                        int ei = indent(ls.get(j)), k = j + 1;
                        while (k < to && indent(ls.get(k)) > ei) k++;
                        if (!er.isEmpty()) { eFrom = -2; elseInline = er; }
                        else {
                            eFrom = j + 1; eTo = k;
                            if (eTo == eFrom && k < to) { eTo = k + 1; k++; }
                        }
                        j = k;
                    }
                    boolean c = cond(cond);
                    if (c) { if (!inline.isEmpty()) one(inline); else block(ls, bodyFrom, bodyTo); }
                    else if (eFrom == -2) one(elseInline);
                    else if (eFrom >= 0) block(ls, eFrom, eTo);
                    i = j;
                    continue;
                }
                one(st);
                i++;
            }
        }
        String elseInline;

        static int close(String s, int lp) {
            int d = 0; boolean q = false;
            for (int i = lp; i < s.length(); i++) {
                char c = s.charAt(i);
                if (c == '\'') q = !q;
                else if (!q && c == '(') d++;
                else if (!q && c == ')' && --d == 0) return i;
            }
            return -1;
        }

        // ------------------------------------------------------------- statements
        void one(String st) {
            String up = st.toUpperCase();
            if (up.equals("EXIT") || up.equals("GOTO")) { stop = true; return; }
            if (up.equals("REFRESH") || up.startsWith("REFRESH ") || up.startsWith("REFRESH(") || up.startsWith("PANEXIT")) return;
            if (up.startsWith("VER") && st.indexOf('(') >= 0 && st.substring(3, st.indexOf('(')).isBlank()) { ver(inside(st)); return; }
            if ((up.startsWith("VPUT") || up.startsWith("VGET")) && (st.length() == 4 || st.charAt(4) == ' ' || st.charAt(4) == '(')) { vpool(up.substring(0, 4), st.substring(4).trim()); return; }
            int eq = assignPos(st);
            if (eq < 0) return;                                   // not recognized: ignored (as ISPEXEC)
            String lhs = st.substring(0, eq).trim(), rhs = st.substring(eq + 1).trim();
            String lu = lhs.toUpperCase();
            if (lu.equals(".CURSOR")) { cursor = (rhs.startsWith("&") ? get(rhs.substring(1)) : unq(rhs)).toUpperCase(); return; }
            if (lu.equals(".MSG")) { String m = rhs.startsWith("&") ? get(rhs.substring(1)) : unq(rhs); msg = m.isBlank() ? null : m.trim(); return; }
            if (lu.equals(".RESP")) { resp = unq(rhs).trim().toUpperCase(); return; }
            if (lu.startsWith(".ATTR")) { attr(lhs, value(rhs)); return; }
            if (lu.startsWith(".")) return;                       // .HELP .ALARM .CSRPOS ... ignored
            String name = lhs.startsWith("&") ? lhs.substring(1) : lhs;
            set(name, value(rhs));
        }

        static String inside(String s) { int lp = s.indexOf('('), rp = close(s, lp); return s.substring(lp + 1, rp < 0 ? s.length() : rp); }

        static int assignPos(String s) {
            boolean q = false;
            int d = 0;
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (c == '\'') q = !q;
                else if (!q && c == '(') d++;
                else if (!q && c == ')') d--;
                else if (!q && d == 0 && c == '=') return i;
            }
            return -1;
        }

        // ------------------------------------------------------------- values
        String get(String name) {
            name = name.trim();
            if (name.endsWith(".")) name = name.substring(0, name.length() - 1);
            String u = name.toUpperCase();
            if (u.equals(".MSG")) return msg == null ? "" : msg;
            if (u.equals(".CURSOR")) return cursor == null ? "" : cursor;
            if (u.equals(".RESP")) return resp == null ? "ENTER" : resp;
            try { if (pn.hasField(u)) return pn.getField(u); } catch (RuntimeException ignore) { }
            if (IspfPanel.ZVarPool.isZVar(u) && zv.has(u)) return zv.get(u);
            if (p != null) { String v = p.rawSym(u); if (v != null) return v; }
            else if (zv.has(u)) return zv.get(u);
            return "";
        }

        void set(String name, String v) {
            String u = name.trim().toUpperCase();
            try { if (pn.hasField(u)) { pn.setField(u, v); return; } } catch (RuntimeException ignore) { }
            if (IspfPanel.ZVarPool.isZVar(u) || p == null) { zv.put(u, v); return; }
            p.setSym(u, v);
        }

        /** 'literal' (with &var substitution), &var, function, word */
        String value(String e) {
            e = e.trim();
            String u = e.toUpperCase();
            if (u.startsWith("TRUNC(")) {
                List<String> a = args(inside(e));
                String s = value(a.get(0));
                if (a.size() > 1) {
                    String t = a.get(1).trim();
                    if (t.startsWith("'")) { String c = unq(t); int k = c.isEmpty() ? -1 : s.indexOf(c.charAt(0)); return k < 0 ? s : s.substring(0, k); }
                    int n = intOr(t, s.length());
                    return s.length() > n ? s.substring(0, n) : s;
                }
                return s;
            }
            if (u.startsWith("TRANS(")) return trans(inside(e));
            if (u.startsWith("UPPER(")) return value(inside(e)).toUpperCase();
            if (u.startsWith("LENGTH(")) return String.valueOf(value(inside(e)).length());
            if (e.startsWith("'")) return subst(unq(e));
            if (e.startsWith("&")) return get(e.substring(1));
            return subst(e);
        }

        String trans(String in) {
            String t = in.trim();
            int sp = firstSep(t);
            String src = value(sp < 0 ? t : t.substring(0, sp));
            String rest = sp < 0 ? "" : t.substring(sp + 1).trim();
            String dflt = null;
            for (String pair : words(rest)) {
                if (pair.toUpperCase().startsWith("MSG=")) continue;
                int c = commaPos(pair);
                if (c < 0) continue;
                String a = unq(pair.substring(0, c).trim()), b = pair.substring(c + 1).trim();
                if (a.equals("*")) { dflt = b.equals("*") ? src : value(b); continue; }
                if (a.equalsIgnoreCase(src)) return b.equals("*") ? src : value(b);
            }
            return dflt == null ? "" : dflt;
        }

        static int firstSep(String s) {
            boolean q = false; int d = 0;
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (c == '\'') q = !q;
                else if (!q && c == '(') d++;
                else if (!q && c == ')') d--;
                else if (!q && d == 0 && (c == ' ' || c == ',')) return i;
            }
            return -1;
        }

        static int commaPos(String s) {
            boolean q = false;
            for (int i = 0; i < s.length(); i++) { char c = s.charAt(i); if (c == '\'') q = !q; else if (!q && c == ',') return i; }
            return -1;
        }

        /** blank separated words, quotes kept together */
        static List<String> words(String s) {
            List<String> r = new ArrayList<>();
            StringBuilder b = new StringBuilder();
            boolean q = false;
            for (char c : s.toCharArray()) {
                if (c == '\'') q = !q;
                if (!q && c == ' ') { if (b.length() > 0) { r.add(b.toString()); b.setLength(0); } continue; }
                b.append(c);
            }
            if (b.length() > 0) r.add(b.toString());
            return r;
        }

        /** comma separated arguments (quotes and parentheses respected) */
        static List<String> args(String s) {
            List<String> r = new ArrayList<>();
            StringBuilder b = new StringBuilder();
            boolean q = false; int d = 0;
            for (char c : s.toCharArray()) {
                if (c == '\'') q = !q;
                else if (!q && c == '(') d++;
                else if (!q && c == ')') d--;
                if (!q && d == 0 && c == ',') { r.add(b.toString().trim()); b.setLength(0); continue; }
                b.append(c);
            }
            r.add(b.toString().trim());
            return r;
        }

        static String unq(String s) {
            s = s.trim();
            if (s.length() >= 2 && s.startsWith("'") && s.endsWith("'")) return s.substring(1, s.length() - 1).replace("''", "'");
            return s;
        }

        /** &NAME substitution (a "." ends the name, && = &) */
        String subst(String s) {
            if (s.indexOf('&') < 0) return s;
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (c != '&') { b.append(c); continue; }
                if (i + 1 < s.length() && s.charAt(i + 1) == '&') { b.append('&'); i++; continue; }
                int j = i + 1;
                while (j < s.length() && (Character.isLetterOrDigit(s.charAt(j)) || "#$@_".indexOf(s.charAt(j)) >= 0)) j++;
                if (j == i + 1) { b.append(c); continue; }
                b.append(get(s.substring(i + 1, j)));
                if (j < s.length() && s.charAt(j) == '.') j++;
                i = j - 1;
            }
            return b.toString();
        }

        static int intOr(String s, int d) { try { return Integer.parseInt(s.trim()); } catch (RuntimeException e) { return d; } }

        // ------------------------------------------------------------- IF conditions
        boolean cond(String c) {
            List<String> or = splitLogic(c, true);
            if (or.size() > 1) { for (String x : or) if (cond(x)) return true; return false; }
            List<String> and = splitLogic(c, false);
            if (and.size() > 1) { for (String x : and) if (!cond(x)) return false; return true; }
            return rel(c.trim());
        }

        static List<String> splitLogic(String s, boolean or) {
            List<String> r = new ArrayList<>();
            boolean q = false; int d = 0, last = 0;
            String U = s.toUpperCase();
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                if (c == '\'') { q = !q; continue; }
                if (q) continue;
                if (c == '(') d++; else if (c == ')') d--;
                if (d != 0) continue;
                int skip = 0;
                if (or) {
                    if (c == '|') skip = 1;
                    else if (U.startsWith(" OR ", i)) skip = 4;
                } else {
                    if (U.startsWith("&&", i)) skip = 2;
                    else if (U.startsWith(" AND ", i)) skip = 5;
                }
                if (skip > 0) { r.add(s.substring(last, i)); last = i + skip; i += skip - 1; }
            }
            r.add(s.substring(last));
            return r;
        }

        static final String[][] OPS = {
            { "\u00ac=", "NE" }, { "\u00ac>", "LE" }, { "\u00ac<", "GE" }, { "<>", "NE" }, { "!=", "NE" }, { ">=", "GE" }, { "<=", "LE" },
            { "=", "EQ" }, { ">", "GT" }, { "<", "LT" } };
        static final Set<String> WOPS = Set.of("EQ", "NE", "GT", "LT", "GE", "LE", "NG", "NL");

        boolean rel(String s) {
            String lhs = null, op = null, rhs = null;
            boolean q = false;
            for (int i = 0; i < s.length() && op == null; i++) {
                char c = s.charAt(i);
                if (c == '\'') { q = !q; continue; }
                if (q) continue;
                for (String[] o : OPS) if (s.startsWith(o[0], i)) { lhs = s.substring(0, i); op = o[1]; rhs = s.substring(i + o[0].length()); break; }
                if (op == null && c == ' ') {
                    List<String> w = words(s.substring(i + 1));
                    if (!w.isEmpty() && WOPS.contains(w.get(0).toUpperCase())) {
                        lhs = s.substring(0, i);
                        op = w.get(0).toUpperCase();
                        if (op.equals("NG")) op = "LE";
                        if (op.equals("NL")) op = "GE";
                        int at = s.toUpperCase().indexOf(w.get(0).toUpperCase(), i + 1);
                        rhs = s.substring(at + w.get(0).length());
                    }
                }
            }
            if (op == null) return !value(s).isBlank();
            String l = value(lhs.trim());
            List<String> vals = new ArrayList<>();
            for (String a : args(rhs.trim())) vals.add(value(a));
            if (op.equals("EQ")) { for (String v : vals) if (cmp(l, v) == 0) return true; return false; }
            if (op.equals("NE")) { for (String v : vals) if (cmp(l, v) == 0) return false; return true; }
            int k = cmp(l, vals.isEmpty() ? "" : vals.get(0));
            return switch (op) { case "GT" -> k > 0; case "LT" -> k < 0; case "GE" -> k >= 0; default -> k <= 0; };
        }

        static int cmp(String a, String b) {
            try { return new java.math.BigDecimal(a.trim()).compareTo(new java.math.BigDecimal(b.trim())); }
            catch (RuntimeException e) { return a.stripTrailing().compareTo(b.stripTrailing()); }
        }

        // ------------------------------------------------------------- VER
        void ver(String in) {
            List<String> a = args(in);
            if (a.isEmpty()) return;
            String var = a.get(0).trim();
            if (var.startsWith("&")) var = var.substring(1);
            var = var.toUpperCase();
            String v = get(var), mid = null;
            List<String> ps = new ArrayList<>();
            for (int i = 1; i < a.size(); i++) {
                String x = a.get(i).trim();
                if (x.toUpperCase().startsWith("MSG=")) mid = x.substring(4).trim(); else ps.add(x);
            }
            boolean nb = false;
            String fail = null;
            int i = 0;
            if (!ps.isEmpty() && ps.get(0).equalsIgnoreCase("NB")) { nb = true; i = 1; }
            if (v.isBlank()) { if (nb) fail = "CAMPO " + var + " OBRIGATORIO"; }
            else if (i < ps.size()) {
                String t = ps.get(i).toUpperCase();
                List<String> rest = ps.subList(i + 1, ps.size());
                String s = v.strip();
                switch (t) {
                    case "NUM": if (!s.matches("[0-9]+")) fail = "CAMPO " + var + " DEVE SER NUMERICO"; break;
                    case "ENUM": if (!s.matches("[+-]?[0-9][0-9,]*(\\.[0-9]*)?|[+-]?\\.[0-9]+")) fail = "CAMPO " + var + " DEVE SER NUMERICO"; break;
                    case "ALPHA": if (!s.matches("[A-Za-z#$@]+")) fail = "CAMPO " + var + " DEVE SER ALFABETICO"; break;
                    case "ALPHAB": if (!s.matches("[A-Za-z]+")) fail = "CAMPO " + var + " DEVE SER ALFABETICO"; break;
                    case "HEX": if (!s.matches("[0-9A-Fa-f]+")) fail = "CAMPO " + var + " DEVE SER HEXADECIMAL"; break;
                    case "BIT": if (!s.matches("[01]+")) fail = "CAMPO " + var + " DEVE SER BINARIO"; break;
                    case "NAME": if (!s.matches("[A-Za-z#$@][A-Za-z0-9#$@]{0,7}")) fail = "CAMPO " + var + ": NOME INVALIDO"; break;
                    case "DSNAME": if (!s.matches("'?[A-Za-z#$@][A-Za-z0-9#$@-]{0,7}(\\.[A-Za-z#$@][A-Za-z0-9#$@-]{0,7})*'?")) fail = "CAMPO " + var + ": DSNAME INVALIDO"; break;
                    case "LIST": case "LISTV": {
                        boolean ok = false;
                        for (String o : rest) if (value(o).equals(s)) ok = true;
                        if (!ok) fail = "CAMPO " + var + ": VALOR NAO PERMITIDO (" + String.join(",", rest) + ")";
                        break;
                    }
                    case "RANGE": {
                        try {
                            java.math.BigDecimal x = new java.math.BigDecimal(s), lo = new java.math.BigDecimal(value(rest.get(0))), hi = new java.math.BigDecimal(value(rest.get(1)));
                            if (x.compareTo(lo) < 0 || x.compareTo(hi) > 0) fail = "CAMPO " + var + " FORA DA FAIXA " + lo + "-" + hi;
                        } catch (RuntimeException e) { fail = "CAMPO " + var + " DEVE SER NUMERICO"; }
                        break;
                    }
                    case "LEN": {
                        String op = rest.size() > 1 ? rest.get(0).trim().toUpperCase() : "LE";
                        int n = intOr(value(rest.get(rest.size() - 1)), 0), L = v.stripTrailing().length();
                        boolean ok = switch (op) { case "=", "EQ" -> L == n; case ">", "GT" -> L > n; case "<", "LT" -> L < n;
                            case ">=", "GE" -> L >= n; case "\u00ac=", "<>", "!=", "NE" -> L != n; default -> L <= n; };
                        if (!ok) fail = "CAMPO " + var + ": TAMANHO INVALIDO (" + op + " " + n + ")";
                        break;
                    }
                    case "PICT": {
                        String pic = unq(rest.isEmpty() ? "" : rest.get(0));
                        if (!pict(s, pic)) fail = "CAMPO " + var + " NAO CONFERE COM O FORMATO " + pic;
                        break;
                    }
                    default: break;
                }
            }
            if (fail != null) {
                valid = false;
                if (msg == null) msg = mid != null ? mid : fail;
                cursor = var;
                stop = true;
            }
        }

        static boolean pict(String s, String pic) {
            if (s.length() != pic.length()) return false;
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i), p = pic.charAt(i);
                boolean ok = switch (p) {
                    case 'C' -> true;
                    case 'A' -> Character.isLetter(c) || "#$@".indexOf(c) >= 0;
                    case 'N' -> Character.isLetterOrDigit(c);
                    case '9' -> Character.isDigit(c);
                    case 'X' -> "0123456789ABCDEFabcdef".indexOf(c) >= 0;
                    default -> c == p;
                };
                if (!ok) return false;
            }
            return true;
        }

        // ------------------------------------------------------------- VPUT / VGET / .ATTR
        void vpool(String verb, String rest) {
            String names = rest, pool = "";
            if (rest.startsWith("(")) { int rp = close(rest, 0); names = rest.substring(1, rp < 0 ? rest.length() : rp); pool = rp < 0 ? "" : rest.substring(rp + 1).trim(); }
            else { List<String> w = words(rest); names = w.isEmpty() ? "" : w.get(0); pool = w.size() > 1 ? w.get(1) : ""; }
            String pl = pool.toUpperCase();
            for (String n0 : names.replace(',', ' ').trim().split("\\s+")) {
                if (n0.isEmpty()) continue;
                String n = (n0.startsWith("&") ? n0.substring(1) : n0).toUpperCase();
                if (verb.equals("VPUT")) {
                    String v = get(n);
                    if (p == null || pl.isEmpty() || pl.equals("SHARED")) zv.put(n, v);         // as the ISPEXEC panel VPUT
                    else { p.setSym(n, v); r2j.IspfApi.ispexec(p, "VPUT (" + n + ") " + pl); }
                } else {
                    if (p == null || pl.isEmpty() || pl.equals("SHARED")) { if (zv.has(n)) set(n, zv.get(n)); }
                    else if (r2j.IspfApi.ispexec(p, "VGET (" + n + ") " + pl) == 0) { String v = p.rawSym(n); if (v != null) set(n, v); }
                }
            }
        }

        /** .ATTR(FIELD) = 'COLOR(RED) INTENS(HIGH) HILITE(REVVID) CAPS(ON) PAD(_) TYPE(OUTPUT)' */
        void attr(String lhs, String spec) {
            String f = inside(lhs).trim();
            if (f.startsWith("&")) f = get(f.substring(1));
            f = f.toUpperCase();
            IspfPanel.IspfAttribute src;
            try { src = IspfPanel.IspfAttribute.parse("X " + spec); } catch (RuntimeException e) { return; }
            String su = spec.toUpperCase();
            for (List<IspfPanel.RenderToken> l : pn.buildFullCanvas())
                for (IspfPanel.RenderToken t : l)
                    if (t instanceof IspfPanel.RenderToken.Field ft) {
                        String n = ft.field.name.toUpperCase();
                        if (!n.equals(f) && !n.startsWith(f + "#")) continue;
                        IspfPanel.IspfAttribute a = ft.field.attr;
                        if (su.contains("TYPE(")) a.type = src.type;
                        if (su.contains("COLOR(")) a.color = src.color;
                        if (su.contains("INTENS(")) a.intens = src.intens;
                        if (su.contains("HILITE(")) a.hilite = src.hilite;
                        if (su.contains("CAPS(")) a.caps = src.caps;
                        if (su.contains("PAD(")) a.pad = src.pad;
                        if (su.contains("JUST(")) a.just = src.just;
                    }
        }
    }

    // ==================================================================================== command parser
    static final class Cmd {
        String verb = "";
        final List<String> pos = new ArrayList<>();
        final Map<String, String> kw = new LinkedHashMap<>();
        boolean has(String w) { for (String s : pos) if (s.equalsIgnoreCase(w)) return true; return false; }
        String kw(String k) { return kw.get(k); }
        String first() { for (String s : pos) if (!s.startsWith("(")) return s; return null; }

        /** VERB pos KW(value) KW('quoted value') ... */
        static Cmd parse(String s) {
            Cmd c = new Cmd();
            int n = s.length(), i = 0;
            boolean first = true;
            while (i < n) {
                while (i < n && (s.charAt(i) == ' ' || s.charAt(i) == ',')) i++;
                if (i >= n) break;
                int st = i;
                while (i < n && s.charAt(i) != ' ' && s.charAt(i) != '(' && s.charAt(i) != ',') i++;
                String w = s.substring(st, i);
                if (i < n && s.charAt(i) == '(') {
                    int d = 0, j = i; boolean q = false;
                    for (; j < n; j++) {
                        char ch = s.charAt(j);
                        if (ch == '\'') q = !q;
                        else if (!q && ch == '(') d++;
                        else if (!q && ch == ')' && --d == 0) break;
                    }
                    String v = s.substring(i + 1, Math.min(j, n)).trim();
                    if (v.length() >= 2 && v.startsWith("'") && v.endsWith("'")) v = v.substring(1, v.length() - 1);
                    if (w.isEmpty()) c.pos.add("(" + v + ")"); else c.kw.put(w.toUpperCase(), v);
                    i = Math.min(j + 1, n);
                    continue;
                }
                if (first) { c.verb = w.toUpperCase(); first = false; } else c.pos.add(w);
            }
            return c;
        }
    }
}
